import React, { useState } from 'react';
import Card from './ui/Card';
import Input from './ui/Input';
import Button from './ui/Button';
import UserCircleIcon from './icons/UserCircleIcon';
import ArrowRightIcon from './icons/ArrowRightIcon';
import { User, DriverData, UserRole } from '../types';
import FileInput from './ui/FileInput';
import Select from './ui/Select';
import { SAUDI_CITIES } from '../constants';

type RegisterPayload = {
    userData: Omit<User, 'id' | 'status'>;
    driverData?: Omit<DriverData, 'id' | 'userId'>;
}

interface LoginRegisterScreenProps {
  onLogin: (mobile: string, password: string) => boolean;
  onRegister: (userData: Omit<User, 'id' | 'status'>, driverData?: Omit<DriverData, 'id' | 'userId'>) => boolean;
  onBack: () => void;
}

const fileToBase64 = (file: File): Promise<string> => new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = error => reject(error);
});


const LoginRegisterScreen: React.FC<LoginRegisterScreenProps> = ({ onLogin, onRegister, onBack }) => {
  const [isRegistering, setIsRegistering] = useState(false);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // User fields
  const [fullName, setFullName] = useState('');
  const [mobile, setMobile] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [profilePicture, setProfilePicture] = useState<File | null>(null);
  const [residencePermit, setResidencePermit] = useState<File | null>(null);
  const [role, setRole] = useState<UserRole>(UserRole.PASSENGER);
  
  // Driver fields
  const [city, setCity] = useState(SAUDI_CITIES[0]);
  const [nationalId, setNationalId] = useState('');
  const [seats, setSeats] = useState('1');
  const [carType, setCarType] = useState('');
  const [carModel, setCarModel] = useState('');
  const [carColor, setCarColor] = useState('');
  const [plateNumber, setPlateNumber] = useState('');
  const [carPictureFront, setCarPictureFront] = useState<File | null>(null);
  const [carPictureRear, setCarPictureRear] = useState<File | null>(null);


  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    if (isRegistering) {
        if (!fullName || !mobile || !password || !email || !profilePicture || !residencePermit) {
            setError('الرجاء تعبئة جميع الحقول الأساسية ورفع الصور المطلوبة.');
            setIsLoading(false);
            return;
        }
        
        let driverPayload: Omit<DriverData, 'id' | 'userId'> | undefined;
        if (role === UserRole.DRIVER) {
            if (!city || !nationalId || !seats || !carType || !carModel || !carColor || !plateNumber || !carPictureFront || !carPictureRear) {
                setError('الرجاء تعبئة جميع بيانات السائق والسيارة.');
                setIsLoading(false);
                return;
            }
            const [carPictureFrontUrl, carPictureRearUrl] = await Promise.all([
                fileToBase64(carPictureFront),
                fileToBase64(carPictureRear),
            ]);
            driverPayload = { city, nationalId, seats, carType, carModel, carColor, plateNumber, carPictureFrontUrl, carPictureRearUrl };
        }

        const [profilePictureUrl, residencePermitUrl] = await Promise.all([
            fileToBase64(profilePicture),
            fileToBase64(residencePermit),
        ]);

        const userPayload: Omit<User, 'id' | 'status'> = {
            fullName, mobile, email, password, role, profilePictureUrl, residencePermitUrl
        };
        
        const success = onRegister(userPayload, driverPayload);
        if (!success) {
            setError('رقم الجوال مسجل مسبقاً. حاول تسجيل الدخول.');
        }

    } else { // Login
        if (!mobile || !password) {
            setError('الرجاء إدخال رقم الجوال وكلمة المرور.');
            setIsLoading(false);
            return;
        }
        const success = onLogin(mobile, password);
        if (!success) {
            setError('رقم الجوال أو كلمة المرور غير صحيحة.');
        }
    }
    setIsLoading(false);
  };
  
  const toggleMode = () => {
      setIsRegistering(!isRegistering);
      setError('');
  }

  return (
    <Card className="max-w-lg mx-auto">
       <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
              <UserCircleIcon className="w-8 h-8 text-sky-600" />
              <h2 className="text-2xl font-bold text-sky-600">{isRegistering ? 'إنشاء حساب جديد' : 'تسجيل الدخول'}</h2>
          </div>
          <button onClick={onBack} className="text-gray-500 hover:text-gray-700">
              <ArrowRightIcon className="w-6 h-6" />
          </button>
      </div>
      
      <form onSubmit={handleSubmit} className="space-y-4" noValidate>
        {isRegistering ? (
            <>
                <p className="text-sm text-center bg-yellow-100 text-yellow-800 p-2 rounded-md">
                    ملاحظة: الخدمة متاحة للسودانيين فقط.
                </p>
                <Input name="fullName" label="الاسم الكامل" onChange={(e) => setFullName(e.target.value)} required />
                <Input name="mobile" type="tel" label="رقم الجوال" onChange={(e) => setMobile(e.target.value)} required />
                <Input name="email" type="email" label="البريد الإلكتروني" onChange={(e) => setEmail(e.target.value)} required />
                <Input name="password" type="password" label="كلمة المرور" onChange={(e) => setPassword(e.target.value)} required />
                <FileInput label="الصورة الشخصية" onChange={(e) => setProfilePicture(e.target.files?.[0] || null)} required accept="image/*" />
                <FileInput label="صورة الإقامة (سارية)" onChange={(e) => setResidencePermit(e.target.files?.[0] || null)} required accept="image/*" />
                
                <div className="pt-2">
                    <label className="block text-sm font-medium text-gray-700 mb-1">نوع الحساب</label>
                    <div className="flex gap-4">
                       <label className="flex items-center gap-2">
                           <input type="radio" name="role" value={UserRole.PASSENGER} checked={role === UserRole.PASSENGER} onChange={() => setRole(UserRole.PASSENGER)} className="form-radio text-sky-600"/>
                           <span>راكب</span>
                       </label>
                       <label className="flex items-center gap-2">
                           <input type="radio" name="role" value={UserRole.DRIVER} checked={role === UserRole.DRIVER} onChange={() => setRole(UserRole.DRIVER)} className="form-radio text-sky-600"/>
                           <span>سائق</span>
                       </label>
                    </div>
                </div>

                {role === UserRole.DRIVER && (
                    <div className="space-y-4 pt-4 border-t mt-4 animate-fade-in-up">
                        <h3 className="font-bold text-gray-800">بيانات السائق والسيارة</h3>
                        <Select name="city" label="المدينة الحالية" value={city} onChange={(e) => setCity(e.target.value)}>
                            {SAUDI_CITIES.map(c => <option key={c} value={c}>{c}</option>)}
                        </Select>
                        <Input name="nationalId" label="رقم الهوية الوطنية" onChange={(e) => setNationalId(e.target.value)} required />
                        <Input name="seats" type="number" label="عدد المقاعد المتاحة" min="1" max="7" value={seats} onChange={(e) => setSeats(e.target.value)} required />
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <Input name="carType" label="نوع السيارة" placeholder="تويوتا كامري" onChange={(e) => setCarType(e.target.value)} required/>
                            <Input name="carModel" label="الموديل" placeholder="2023" onChange={(e) => setCarModel(e.target.value)} required/>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <Input name="carColor" label="اللون" placeholder="أبيض" onChange={(e) => setCarColor(e.target.value)} required/>
                            <Input name="plateNumber" label="رقم اللوحة" placeholder="أ ب ج 1234" onChange={(e) => setPlateNumber(e.target.value)} required/>
                        </div>
                        <FileInput label="صورة السيارة من الأمام" onChange={(e) => setCarPictureFront(e.target.files?.[0] || null)} required accept="image/*" />
                        <FileInput label="صورة السيارة من الخلف" onChange={(e) => setCarPictureRear(e.target.files?.[0] || null)} required accept="image/*" />
                    </div>
                )}
            </>
        ) : (
            <>
                <Input name="mobile" type="tel" label="رقم الجوال" placeholder="05xxxxxxxx" value={mobile} onChange={(e) => setMobile(e.target.value)} required/>
                <Input name="password" type="password" label="كلمة المرور" placeholder="ادخل كلمة المرور" value={password} onChange={(e) => setPassword(e.target.value)} required/>
            </>
        )}

        {error && <p className="text-red-500 text-sm text-center pt-2">{error}</p>}
        <Button type="submit" className="w-full !mt-6" disabled={isLoading}>
            {isLoading ? 'جاري ...' : (isRegistering ? 'إنشاء حساب' : 'تسجيل الدخول')}
        </Button>
      </form>
      <div className="mt-6 text-center">
        <button onClick={toggleMode} className="text-sm text-sky-600 hover:underline font-semibold">
            {isRegistering ? 'لديك حساب بالفعل؟ تسجيل الدخول' : 'ليس لديك حساب؟ إنشاء حساب جديد'}
        </button>
      </div>
    </Card>
  );
};

export default LoginRegisterScreen;