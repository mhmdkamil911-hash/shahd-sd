import React from 'react';
import { Trip } from '../types';
import Button from './ui/Button';
import WhatsAppIcon from './icons/WhatsAppIcon';
import PhoneIcon from './icons/PhoneIcon';
import BoxIcon from './icons/BoxIcon';

interface ParcelModalProps {
  trip: Trip;
  onClose: () => void;
  onConfirmParcelDelivery: (tripId: string) => void;
}

const ParcelModal: React.FC<ParcelModalProps> = ({ trip, onClose, onConfirmParcelDelivery }) => {
  const handleConfirm = () => {
    onConfirmParcelDelivery(trip.id);
  };

  const whatsappNumber = `+966${trip.driverMobile.substring(1)}`;

  return (
    <div 
      className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4"
      onClick={onClose}
    >
      <div 
        className="bg-white rounded-xl shadow-2xl p-6 sm:p-8 w-full max-w-md text-center transform transition-all animate-fade-in-up"
        onClick={(e) => e.stopPropagation()}
      >
        <BoxIcon className="w-12 h-12 mx-auto text-teal-500 mb-3" />
        <h2 className="text-2xl font-bold text-teal-600 mb-2">توصيل طرد مع الرحلة</h2>
        <p className="text-gray-600 mb-6">
            لإرسال طرد مع الرحلة من <span className="font-bold">{trip.from}</span> إلى <span className="font-bold">{trip.to}</span>، اتبع الخطوات التالية:
        </p>

        {/* Step 1: Contact Driver */}
        <div className="bg-gray-50 p-4 rounded-lg mb-4 text-right">
            <h3 className="font-bold text-lg text-gray-800 mb-3">1. تواصل مع السائق للاتفاق</h3>
            <p className="text-sm text-gray-600 mb-3">تواصل مع السائق للاتفاق على تفاصيل الطرد (الحجم، السعر، محتوى الطرد) قبل التأكيد.</p>
            <div className="grid grid-cols-2 gap-3 mt-4">
                <a 
                    href={`https://wa.me/${whatsappNumber}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-center gap-2 w-full bg-green-500 text-white font-bold py-2 px-4 rounded-lg hover:bg-green-600 transition duration-300"
                >
                    <WhatsAppIcon className="w-5 h-5" />
                    <span>واتساب</span>
                </a>
                <a 
                    href={`tel:${trip.driverMobile}`}
                    className="flex items-center justify-center gap-2 w-full bg-sky-500 text-white font-bold py-2 px-4 rounded-lg hover:bg-sky-600 transition duration-300"
                >
                    <PhoneIcon className="w-5 h-5" />
                    <span>اتصال</span>
                </a>
            </div>
        </div>

        {/* Step 2: Confirm Parcel */}
        <div className="bg-teal-50 p-4 rounded-lg mb-6">
            <h3 className="font-bold text-lg text-gray-800 mb-2">2. قم بتأكيد إرسال الطرد</h3>
            <p className="text-sm text-gray-600 mb-4">بعد الاتفاق مع السائق، اضغط أدناه لتأكيد العملية وتسجيلها في حسابك.</p>
            <Button
                onClick={handleConfirm}
                className="w-full bg-teal-600 text-white font-bold py-3 px-4 rounded-lg hover:bg-teal-700"
            >
                تأكيد توصيل الطرد
            </Button>
        </div>

        <Button
            onClick={onClose}
            className="w-full bg-transparent text-gray-600 hover:bg-gray-100 font-semibold !py-2"
        >
            إغلاق
        </Button>
      </div>
    </div>
  );
};

export default ParcelModal;
