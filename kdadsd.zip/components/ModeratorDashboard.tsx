import React from 'react';
import { DriverData, User, UserStatus } from '../types';
import Card from './ui/Card';
import Button from './ui/Button';
import ArrowRightIcon from './icons/ArrowRightIcon';
import LogoutIcon from './icons/LogoutIcon';
import ShieldCheckIcon from './icons/ShieldCheckIcon';

interface ModeratorDashboardProps {
  pendingDrivers: User[];
  driversData: DriverData[];
  onUserStatusUpdate: (userId: string, status: UserStatus) => void;
  onBack: () => void;
  onLogout: () => void;
}

const InfoRow: React.FC<{ label: string, value: React.ReactNode }> = ({ label, value }) => (
    <p className="text-sm text-gray-600 truncate"><span className="font-semibold text-gray-800">{label}:</span> {value}</p>
);

const ModeratorDashboard: React.FC<ModeratorDashboardProps> = ({ pendingDrivers, driversData, onUserStatusUpdate, onBack, onLogout }) => {
  return (
    <Card className="max-w-4xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <ShieldCheckIcon className="w-8 h-8 text-sky-600" />
          <h2 className="text-2xl font-bold text-sky-600">لوحة تحكم المشرف</h2>
        </div>
        <div className="flex items-center gap-4">
          <button onClick={onLogout} className="text-sm font-semibold text-red-500 hover:text-red-700 flex items-center gap-1.5 transition-colors">
            <LogoutIcon className="w-5 h-5" />
            <span>تسجيل الخروج</span>
          </button>
          <button onClick={onBack} className="text-gray-500 hover:text-gray-700">
            <ArrowRightIcon className="w-6 h-6" />
          </button>
        </div>
      </div>

      <div className="space-y-8">
        <h3 className="text-xl font-bold text-gray-800">طلبات السائقين المعلقة ({pendingDrivers.length})</h3>
        {pendingDrivers.length === 0 ? (
          <p className="text-gray-500 bg-gray-50 p-4 rounded-lg">لا توجد طلبات معلقة حالياً.</p>
        ) : (
          <div className="space-y-4 max-h-[70vh] overflow-y-auto pr-2">
            {pendingDrivers.map(user => {
              const driver = driversData.find(d => d.userId === user.id);
              if (!driver) return null;

              return (
                <div key={user.id} className="bg-white p-4 rounded-lg border border-gray-200 shadow-sm">
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-x-6 gap-y-4">
                    <div className="space-y-2">
                      <InfoRow label="الاسم" value={user.fullName} />
                      <InfoRow label="الجوال" value={user.mobile} />
                      <InfoRow label="الإيميل" value={user.email} />
                    </div>
                    <div className="flex items-center justify-center gap-2">
                      <a href={user.profilePictureUrl} target="_blank" rel="noopener noreferrer" className="text-center block hover:opacity-80 transition-opacity">
                        <img src={user.profilePictureUrl} className="w-20 h-20 object-cover rounded-full mx-auto border-2 border-gray-200" alt="شخصية" />
                        <span className="text-xs text-gray-500 mt-1">صورة شخصية</span>
                      </a>
                      <a href={user.residencePermitUrl} target="_blank" rel="noopener noreferrer" className="text-center block hover:opacity-80 transition-opacity">
                        <img src={user.residencePermitUrl} className="w-20 h-20 object-cover rounded-lg mx-auto border-2 border-gray-200" alt="إقامة" />
                        <span className="text-xs text-gray-500 mt-1">صورة الإقامة</span>
                      </a>
                    </div>
                    <div className="space-y-2">
                      <InfoRow label="السيارة" value={`${driver.carType} ${driver.carModel}`} />
                      <InfoRow label="اللون" value={driver.carColor} />
                      <InfoRow label="اللوحة" value={driver.plateNumber} />
                      <InfoRow label="المقاعد" value={driver.seats} />
                    </div>
                    <div className="flex items-center justify-center gap-2">
                      <a href={driver.carPictureFrontUrl} target="_blank" rel="noopener noreferrer" className="text-center block hover:opacity-80 transition-opacity">
                        <img src={driver.carPictureFrontUrl} className="w-20 h-20 object-cover rounded-lg mx-auto border-2 border-gray-200" alt="سيارة أمام" />
                        <span className="text-xs text-gray-500 mt-1">سيارة (أمام)</span>
                      </a>
                      <a href={driver.carPictureRearUrl} target="_blank" rel="noopener noreferrer" className="text-center block hover:opacity-80 transition-opacity">
                        <img src={driver.carPictureRearUrl} className="w-20 h-20 object-cover rounded-lg mx-auto border-2 border-gray-200" alt="سيارة خلف" />
                        <span className="text-xs text-gray-500 mt-1">سيارة (خلف)</span>
                      </a>
                    </div>
                  </div>
                  <div className="mt-4 flex items-center justify-end gap-3">
                    <Button onClick={() => onUserStatusUpdate(user.id, 'active')} className="bg-green-500 hover:bg-green-600 !py-2">موافقة</Button>
                    <Button onClick={() => onUserStatusUpdate(user.id, 'rejected')} className="bg-red-500 hover:bg-red-600 !py-2">رفض</Button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </Card>
  );
};

export default ModeratorDashboard;
