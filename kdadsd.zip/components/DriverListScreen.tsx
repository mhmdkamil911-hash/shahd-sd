
import React, { useMemo } from 'react';
import { DriverData } from '../types';
import Card from './ui/Card';
import ArrowRightIcon from './icons/ArrowRightIcon';
import SteeringWheelIcon from './icons/SteeringWheelIcon';
import CarIcon from './icons/CarIcon';
import TagIcon from './icons/TagIcon';
import UsersIcon from './icons/UsersIcon';
import PhoneIcon from './icons/PhoneIcon';

// FIX: Define an augmented type for drivers to include user details.
interface AugmentedDriverData extends DriverData {
  fullName: string;
  mobile: string;
  profilePictureUrl: string;
}

interface DriverListScreenProps {
  // FIX: Update prop type to use the augmented driver data.
  drivers: AugmentedDriverData[];
  onBack: () => void;
}

const mapArabicColorToCss = (arabicColor: string): string => {
    if (!arabicColor) return '#A0AEC0'; // Default gray
    const color = arabicColor.toLowerCase().trim();
    const colorMap: { [key: string]: string } = {
        'أبيض': '#FFFFFF',
        'white': '#FFFFFF',
        'اسود': '#333333',
        'أسود': '#333333',
        'black': '#333333',
        'احمر': '#E53E3E',
        'أحمر': '#E53E3E',
        'red': '#E53E3E',
        'ازرق': '#3182CE',
        'أزرق': '#3182CE',
        'blue': '#3182CE',
        'اخضر': '#38A169',
        'أخضر': '#38A169',
        'green': '#38A169',
        'اصفر': '#D69E2E',
        'أصفر': '#D69E2E',
        'yellow': '#D69E2E',
        'فضي': '#E2E8F0',
        'silver': '#E2E8F0',
        'رمادي': '#A0AEC0',
        'gray': '#A0AEC0',
        'grey': '#A0AEC0',
        'رصاصي': '#718096',
        'gunmetal': '#718096',
        'ذهبي': '#FBBF24',
        'gold': '#FBBF24',
        'بني': '#874A33',
        'brown': '#874A33',
        'بيج': '#F5E8D8',
        'beige': '#F5E8D8',
        'كحلي': '#2C5282',
        'navy': '#2C5282',
        'برتقالي': '#DD6B20',
        'orange': '#DD6B20',
    };
    return colorMap[color] || '#A0AEC0';
};


const DriverListScreen: React.FC<DriverListScreenProps> = ({ drivers, onBack }) => {
  const driversByCity = useMemo(() => {
    return drivers.reduce((acc, driver) => {
      const city = driver.city;
      if (!acc[city]) {
        acc[city] = [];
      }
      acc[city].push(driver);
      // FIX: Use correctly typed accumulator.
      return acc;
    }, {} as Record<string, AugmentedDriverData[]>);
  }, [drivers]);

  return (
    <Card className="max-w-4xl mx-auto !bg-white/90 backdrop-blur-sm">
      <div className="flex items-center justify-between mb-6 border-b pb-4">
        <div className="flex items-center gap-3">
            <SteeringWheelIcon className="w-8 h-8 text-sky-600" />
            <h2 className="text-2xl font-bold text-sky-600">قائمة السائقين المعتمدين</h2>
        </div>
        <button onClick={onBack} className="text-gray-500 hover:text-gray-700">
          <ArrowRightIcon className="w-6 h-6" />
        </button>
      </div>

      {drivers.length > 0 ? (
        <div className="space-y-8">
          {Object.keys(driversByCity).sort().map(city => (
            <div key={city}>
              <h3 className="text-xl font-bold text-gray-800 mb-4 bg-gray-100 p-2 rounded-md">{city}</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {driversByCity[city].map(driver => {
                    // FIX: Removed incorrect user lookup. Data is now in `driver` prop.
                    return (
                      <div key={driver.id} className="bg-white rounded-lg border flex flex-col h-full shadow-sm hover:shadow-md transition-shadow duration-300 overflow-hidden">
                        {driver.carPictureFrontUrl && <img src={driver.carPictureFrontUrl} alt={driver.carType} className="w-full h-32 object-cover" />}
                        <div className="p-4 flex flex-col flex-grow">
                          <div className="flex items-center gap-3 border-b pb-3 mb-3">
                              <div className="bg-sky-100 p-2 rounded-full flex-shrink-0">
                                  {/* FIX: Use profilePictureUrl from augmented driver data. */}
                                  {driver.profilePictureUrl ? (
                                    <img src={driver.profilePictureUrl} alt={driver.fullName} className="w-8 h-8 rounded-full object-cover"/>
                                  ) : (
                                    <SteeringWheelIcon className="w-6 h-6 text-sky-600" />
                                  )}
                              </div>
                              {/* FIX: Use fullName from augmented driver data. */}
                              <h4 className="font-bold text-gray-900 text-lg truncate">{driver.fullName}</h4>
                          </div>
                          <div className="space-y-2 text-gray-700 flex-grow">
                              <div className="flex items-center gap-2">
                                  <CarIcon className="w-5 h-5 text-gray-400 flex-shrink-0" />
                                  <span className="text-sm">{driver.carType}</span>
                              </div>
                              <div className="flex items-center gap-2">
                                  <TagIcon className="w-5 h-5 text-gray-400 flex-shrink-0" />
                                  <span className="text-sm">موديل {driver.carModel}</span>
                                  <span
                                      title={driver.carColor}
                                      className="w-4 h-4 rounded-full border border-gray-300 shadow-inner"
                                      style={{ backgroundColor: mapArabicColorToCss(driver.carColor) }}
                                  ></span>
                              </div>
                              <div className="flex items-center gap-2">
                                  <UsersIcon className="w-5 h-5 text-gray-400 flex-shrink-0" />
                                  <span className="text-sm font-medium"><span className="font-bold text-sky-600">{driver.seats}</span> مقاعد متاحة</span>
                              </div>
                          </div>
                          <div className="pt-3 border-t mt-3">
                              <div className="flex items-center gap-2">
                                  <PhoneIcon className="w-5 h-5 text-gray-400 flex-shrink-0" />
                                  {/* FIX: Use mobile from augmented driver data and fix href. */}
                                  <a href={'tel:' + driver.mobile} className="text-sm text-sky-600 hover:underline font-semibold tracking-wider">{driver.mobile}</a>
                              </div>
                          </div>
                        </div>
                      </div>
                    );
                })}
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-16">
          <h3 className="text-2xl font-bold text-gray-700">لا يوجد سائقين معتمدين بعد</h3>
          <p className="text-gray-500 mt-2">سيتم عرض السائقين هنا بعد مراجعة طلباتهم والموافقة عليها.</p>
        </div>
      )}
    </Card>
  );
};

export default DriverListScreen;
