import React, { useState, useMemo, useEffect, useRef } from 'react';
import { Trip, View, Hotel, NewsItem, GalleryImage, User, UserRole, SudaneseGathering } from '../types';
import { SAUDI_CITIES } from '../constants';
import TripCard from './TripCard';
import NewsTicker from './NewsTicker';
import Button from './ui/Button';
import AdminIcon from './icons/AdminIcon';
import CarIcon from './icons/CarIcon';
import SteeringWheelIcon from './icons/SteeringWheelIcon';
import HotelIcon from './icons/HotelIcon';
import UserCircleIcon from './icons/UserCircleIcon';
import BoxIcon from './icons/BoxIcon';
import ShopIcon from './icons/ShopIcon';
import LocationPinIcon from './icons/LocationPinIcon';
import ArrowRightIcon from './icons/ArrowRightIcon';
import XIcon from './icons/XIcon';


interface TripListScreenProps {
  trips: Trip[];
  hotels: Hotel[];
  newsItems: NewsItem[];
  galleryImages: GalleryImage[];
  gatherings: SudaneseGathering[];
  currentUser: User | null;
  isDriverApproved: boolean;
  onStartBooking: (trip: Trip) => void;
  onStartParcelDelivery: (trip: Trip) => void;
  onNavigate: (view: View) => void;
}

const TripListScreen: React.FC<TripListScreenProps> = ({ trips, hotels, newsItems, galleryImages, gatherings, currentUser, isDriverApproved, onStartBooking, onStartParcelDelivery, onNavigate }) => {
  const [fromCity, setFromCity] = useState('');
  const [toCity, setToCity] = useState('');
  const galleryRef = useRef<HTMLDivElement>(null);

  const combinedGallery = useMemo(() => {
    const adminImages = galleryImages.map(img => ({
        id: img.id,
        imageUrl: img.imageUrl,
        title: '',
        type: 'gallery' as const,
    }));

    const hotelImages = hotels.flatMap(hotel => 
        hotel.images.map((img, index) => ({
            id: `${hotel.id}-${index}`,
            imageUrl: img,
            title: hotel.name,
            type: 'hotel' as const,
        }))
    );

    const gatheringImages = gatherings.flatMap(gathering => 
        gathering.images.map((img, index) => ({
            id: `${gathering.id}-${index}`,
            imageUrl: img,
            title: gathering.name,
            type: 'gathering' as const,
        }))
    );

    const allImages = [...adminImages, ...hotelImages, ...gatheringImages];
    
    // Shuffle the array to make the gallery dynamic on each load
    for (let i = allImages.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [allImages[i], allImages[j]] = [allImages[j], allImages[i]];
    }

    return allImages;
  }, [galleryImages, hotels, gatherings]);

  useEffect(() => {
    if (combinedGallery.length > 1) {
      const interval = setInterval(() => {
        if (galleryRef.current) {
          const { scrollLeft, scrollWidth, clientWidth } = galleryRef.current;
          const isAtEnd = scrollLeft >= scrollWidth - clientWidth - 1;
          const scrollAmount = clientWidth * 0.8; 

          if (isAtEnd) {
            galleryRef.current.scrollTo({ left: 0, behavior: 'smooth' });
          } else {
            galleryRef.current.scrollBy({ left: scrollAmount, behavior: 'smooth' });
          }
        }
      }, 4000); // Change image every 4 seconds

      return () => clearInterval(interval);
    }
  }, [combinedGallery]);

  const filteredTrips = useMemo(() => {
    return trips.filter(trip => {
      const fromMatch = fromCity ? trip.from === fromCity : true;
      const toMatch = toCity ? trip.to === toCity : true;
      return fromMatch && toMatch;
    });
  }, [trips, fromCity, toCity]);
  
  const hotelsWithImages = useMemo(() => {
    return hotels.filter(h => h.images && h.images.length > 0);
  }, [hotels]);

  const renderHeaderActions = () => {
    if (currentUser && currentUser.status === 'active') {
      return (
        <>
          <span className="text-gray-700 font-semibold">مرحباً, {currentUser.fullName.split(' ')[0]}</span>
          <Button onClick={() => onNavigate(View.ACCOUNT_HISTORY)} className="!py-2 !px-4 text-sm bg-gray-700 hover:bg-gray-800 flex items-center gap-2">
              <UserCircleIcon className="w-5 h-5"/>
              <span>حسابي</span>
          </Button>
          {currentUser.role === UserRole.DRIVER && isDriverApproved && (
             <Button onClick={() => onNavigate(View.POST_TRIP)} className="!py-2 !px-4 text-sm flex items-center gap-2">
                <CarIcon className="w-5 h-5"/>
                <span>أضف رحلة</span>
            </Button>
          )}
        </>
      );
    } else {
      return (
        <>
            <Button onClick={() => onNavigate(View.LOGIN_REGISTER)} className="!py-2 !px-4 text-sm flex items-center gap-2">
                <UserCircleIcon className="w-5 h-5"/>
                <span>دخول / تسجيل</span>
           </Button>
        </>
      );
    }
  };


  return (
    <div className="w-full">
      <header className="bg-white/80 backdrop-blur-sm p-4 rounded-xl shadow-lg mb-8 text-center">
        <h1 className="text-4xl font-bold text-sky-600 flex items-center justify-center gap-3">
          <CarIcon className="w-12 h-12 text-gray-700" />
          <span>كداد سوداني</span>
          <BoxIcon className="w-10 h-10 text-teal-600" />
        </h1>
        <p className="text-lg text-gray-600 my-2">داخل المملكة العربية السعودية</p>
        <div className="flex flex-wrap items-center justify-center gap-3 pt-4">
           {renderHeaderActions()}
            <Button onClick={() => onNavigate(View.DRIVERS_LIST)} className="!py-2 !px-4 text-sm bg-teal-600 hover:bg-teal-700 flex items-center gap-2">
                <SteeringWheelIcon className="w-5 h-5"/>
                <span>قائمة السائقين</span>
           </Button>
            <Button onClick={() => onNavigate(View.HOTELS_LIST)} className="!py-2 !px-4 text-sm bg-amber-600 hover:bg-amber-700 flex items-center gap-2">
                <HotelIcon className="w-5 h-5"/>
                <span>أفضل الفنادق</span>
           </Button>
           <Button onClick={() => onNavigate(View.GATHERINGS)} className="!py-2 !px-4 text-sm bg-indigo-600 hover:bg-indigo-700 flex items-center gap-2">
                <ShopIcon className="w-5 h-5"/>
                <span>تجمعات سودانية</span>
           </Button>
            <button
            onClick={() => onNavigate(View.ADMIN_DASHBOARD)}
            className="inline-flex items-center text-sm text-gray-500 hover:text-sky-600 transition-colors duration-300 font-semibold gap-1"
          >
            <AdminIcon className="w-5 h-5" />
            <span>لوحة الإدارة</span>
          </button>
        </div>
      </header>

      {combinedGallery.length > 0 && (
        <section className="mb-8">
           <div ref={galleryRef} className="flex overflow-x-auto gap-4 pb-4 scroll-smooth snap-x snap-mandatory">
            {combinedGallery.map(image => (
              <div key={image.id} className="relative flex-shrink-0 w-80 h-48 bg-black/20 rounded-lg shadow-md overflow-hidden snap-center group">
                <img src={image.imageUrl} alt={image.title} className="w-full h-full object-contain transition-transform duration-300 group-hover:scale-105" loading="lazy" />
                <div className="absolute bottom-0 left-0 right-0 p-3 bg-gradient-to-t from-black/70 to-transparent">
                    <h3 className="text-white font-semibold text-shadow truncate">{image.title}</h3>
                    {image.type !== 'gallery' && (
                         <span className={`text-xs px-2 py-0.5 rounded-full text-white ${image.type === 'hotel' ? 'bg-amber-600/80' : 'bg-indigo-600/80'}`}>
                             {image.type === 'hotel' ? 'فندق' : 'تجمعات'}
                         </span>
                    )}
                </div>
              </div>
            ))}
          </div>
        </section>
      )}
      
      {newsItems.length > 0 && <NewsTicker items={newsItems} />}
      
      {hotelsWithImages.length > 0 && (
        <section className="mb-8">
          <h2 className="text-2xl font-bold text-gray-800 mb-4">فنادق موصى بها</h2>
          <div className="flex overflow-x-auto gap-4 pb-4">
            {hotelsWithImages.map(hotel => (
              <div key={hotel.id} className="flex-shrink-0 w-64 bg-white/90 backdrop-blur-sm rounded-lg shadow-md overflow-hidden transform hover:-translate-y-1 transition-transform duration-300">
                <img src={hotel.images[0]} alt={hotel.name} className="w-full h-32 object-cover" loading="lazy" />
                <div className="p-3">
                  <h3 className="font-bold text-gray-800 truncate">{hotel.name}</h3>
                  <p className="text-sm text-gray-500">{hotel.contact}</p>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      <main>
        <div className="bg-white/80 backdrop-blur-sm p-3 rounded-xl shadow-lg mb-8 flex items-center gap-2">
            <div className="flex-grow flex items-center gap-2 bg-white rounded-lg border border-gray-200 shadow-inner p-1">
                {/* From City */}
                <div className="relative flex-1">
                    <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                        <LocationPinIcon className="w-5 h-5 text-gray-400" />
                    </div>
                    <select
                        aria-label="الانطلاق من"
                        value={fromCity}
                        onChange={e => setFromCity(e.target.value)}
                        className="w-full pl-3 pr-10 py-2 border-none rounded-md focus:ring-2 focus:ring-sky-500 appearance-none bg-transparent text-gray-700 font-medium"
                    >
                        <option value="">الانطلاق من...</option>
                        {SAUDI_CITIES.map(city => <option key={`from-${city}`} value={city}>{city}</option>)}
                    </select>
                </div>

                {/* Arrow Separator */}
                <ArrowRightIcon className="w-6 h-6 text-gray-300 flex-shrink-0 transform -scale-x-100"/>

                {/* To City */}
                 <div className="relative flex-1">
                     <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                        <LocationPinIcon className="w-5 h-5 text-gray-400" />
                    </div>
                    <select
                        aria-label="الوصول إلى"
                        value={toCity}
                        onChange={e => setToCity(e.target.value)}
                        className="w-full pl-3 pr-10 py-2 border-none rounded-md focus:ring-2 focus:ring-sky-500 appearance-none bg-transparent text-gray-700 font-medium"
                    >
                        <option value="">الوصول إلى...</option>
                        {SAUDI_CITIES.map(city => <option key={`to-${city}`} value={city}>{city}</option>)}
                    </select>
                </div>
            </div>

            {/* Clear Button */}
            {(fromCity || toCity) && (
                <button
                    onClick={() => { setFromCity(''); setToCity(''); }}
                    className="flex-shrink-0 p-2.5 rounded-lg bg-gray-200 text-gray-600 hover:bg-red-100 hover:text-red-600 transition-colors"
                    aria-label="مسح البحث"
                >
                    <XIcon className="w-5 h-5" />
                </button>
            )}
        </div>
        
        {filteredTrips.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                {filteredTrips.map(trip => (
                    <TripCard key={trip.id} trip={trip} onBook={onStartBooking} onDeliverParcel={onStartParcelDelivery} />
                ))}
            </div>
        ) : (
            <div className="text-center py-16 bg-white/80 backdrop-blur-sm rounded-lg shadow-md">
                <h3 className="text-2xl font-bold text-gray-700">لا توجد رحلات مطابقة لبحثك</h3>
                <p className="text-gray-500 mt-2">حاول تغيير فلاتر البحث، أو تفقد الرحلات لاحقاً.</p>
            </div>
        )}

      </main>
    </div>
  );
};

export default TripListScreen;