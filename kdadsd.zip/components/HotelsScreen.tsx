import React, { useState } from 'react';
import { Hotel } from '../types';
import Card from './ui/Card';
import Input from './ui/Input';
import Button from './ui/Button';
import FileInput from './ui/FileInput';
import ArrowRightIcon from './icons/ArrowRightIcon';
import LocationPinIcon from './icons/LocationPinIcon';
import HotelIcon from './icons/HotelIcon';
import CrosshairIcon from './icons/CrosshairIcon';

interface HotelsScreenProps {
  hotels: Hotel[];
  onAddHotel: (hotelData: Omit<Hotel, 'id'>) => void;
  onBack: () => void;
}

const fileToBase64 = (file: File): Promise<string> => new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = error => reject(error);
});

const HotelsScreen: React.FC<HotelsScreenProps> = ({ hotels, onAddHotel, onBack }) => {
  const [formData, setFormData] = useState({
    name: '',
    contact: '',
    locationUrl: '',
  });
  const [imageFiles, setImageFiles] = useState<File[]>([]);
  const [imagePreviews, setImagePreviews] = useState<string[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isFetchingLocation, setIsFetchingLocation] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const filesArray = Array.from(e.target.files);
      setImageFiles(filesArray);
      
      const previews = filesArray.map(file => URL.createObjectURL(file));
      setImagePreviews(previews);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSubmitting) return;
    setIsSubmitting(true);
    
    let imageBase64Strings: string[] = [];
    if (imageFiles.length > 0) {
        imageBase64Strings = await Promise.all(
            imageFiles.map(file => fileToBase64(file))
        );
    }

    onAddHotel({ ...formData, images: imageBase64Strings });
    
    // Reset form
    setFormData({ name: '', contact: '', locationUrl: '' });
    setImageFiles([]);
    setImagePreviews([]);
    const fileInput = document.getElementById('hotel-images') as HTMLInputElement;
    if (fileInput) fileInput.value = '';

    setIsSubmitting(false);
  };

  const handleGetCurrentLocation = () => {
    if (!navigator.geolocation) {
      alert('الموقع الجغرافي غير مدعوم في هذا المتصفح.');
      return;
    }
    setIsFetchingLocation(true);
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude } = position.coords;
        const googleMapsUrl = `https://www.google.com/maps?q=${latitude},${longitude}`;
        setFormData(prev => ({...prev, locationUrl: googleMapsUrl }));
        setIsFetchingLocation(false);
      },
      (error) => {
        console.error("Geolocation error:", error);
        alert('لا يمكن الحصول على الموقع. يرجى التأكد من تفعيل خدمات الموقع والموافقة على الإذن.');
        setIsFetchingLocation(false);
      }
    );
  };


  return (
    <Card className="max-w-4xl mx-auto !bg-white/90 backdrop-blur-sm">
      <div className="flex items-center justify-between mb-6 border-b pb-4">
         <div className="flex items-center gap-3">
            <HotelIcon className="w-8 h-8 text-amber-600" />
            <h2 className="text-2xl font-bold text-sky-600">الفنادق الموصى بها</h2>
        </div>
        <button onClick={onBack} className="text-gray-500 hover:text-gray-700">
          <ArrowRightIcon className="w-6 h-6" />
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Add Hotel Form */}
        <div>
          <h3 className="text-xl font-bold text-gray-800 mb-4">إضافة فندق جديد</h3>
          <form onSubmit={handleSubmit} className="space-y-4">
            <Input name="name" label="اسم الفندق" placeholder="مثال: فندق الراحة" value={formData.name} onChange={handleChange} required />
            <Input name="contact" type="tel" label="رقم التواصل" placeholder="05xxxxxxxx" value={formData.contact} onChange={handleChange} required />
            
            <div>
              <label htmlFor="locationUrl" className="block text-sm font-medium text-gray-700 mb-1">
                رابط الموقع على الخريطة
              </label>
              <div className="relative">
                <input 
                    id="locationUrl"
                    name="locationUrl" 
                    type="url" 
                    placeholder="https://maps.google.com/..." 
                    value={formData.locationUrl} 
                    onChange={handleChange} 
                    required
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-sky-500 focus:border-sky-500 transition duration-150"
                />
                 <div className="absolute inset-y-0 left-0 flex items-center pl-3">
                    <LocationPinIcon className="h-5 w-5 text-gray-400" />
                </div>
              </div>
               <Button type="button" onClick={handleGetCurrentLocation} className="!py-1.5 !px-3 text-sm mt-2 w-full flex items-center justify-center gap-2 bg-gray-600 hover:bg-gray-700" disabled={isFetchingLocation}>
                  <CrosshairIcon className="w-4 h-4" />
                  <span>{isFetchingLocation ? 'جاري التحديد...' : 'استخدام موقعي الحالي'}</span>
               </Button>
            </div>

            <FileInput id="hotel-images" name="images" label="صور الفندق (اختياري، متعدد)" onChange={handleFileChange} multiple accept="image/*" />
            {imagePreviews.length > 0 && (
                <div className="flex flex-wrap gap-2 mt-2">
                    {imagePreviews.map((src, index) => (
                        <img key={index} src={src} alt={`Preview ${index+1}`} className="w-16 h-16 object-cover rounded-md border" />
                    ))}
                </div>
            )}
            
            <Button type="submit" className="w-full mt-4" disabled={isSubmitting}>
              {isSubmitting ? 'جاري الإضافة...' : 'إضافة فندق'}
            </Button>
          </form>
        </div>

        {/* Hotels List */}
        <div>
          <h3 className="text-xl font-bold text-gray-800 mb-4">الفنادق المضافة ({hotels.length})</h3>
          {hotels.length > 0 ? (
            <div className="space-y-4 max-h-[60vh] overflow-y-auto pr-2">
              {hotels.map(hotel => (
                <div key={hotel.id} className="bg-white p-4 rounded-lg border flex gap-4 items-center">
                  {hotel.images && hotel.images.length > 0 && (
                    <img src={hotel.images[0]} alt={hotel.name} className="w-24 h-24 object-cover rounded-md flex-shrink-0 bg-gray-100" />
                  )}
                  <div className="flex-grow">
                    <h4 className="font-bold text-gray-900">{hotel.name}</h4>
                    <p className="text-sm text-gray-600 mt-1"><strong>للتواصل:</strong> {hotel.contact}</p>
                    {hotel.locationUrl && (
                        <a href={hotel.locationUrl} target="_blank" rel="noopener noreferrer" className="text-sm text-sky-600 hover:underline flex items-center gap-1 mt-2">
                           <LocationPinIcon className="w-4 h-4" />
                           <span>عرض على الخريطة</span>
                        </a>
                    )}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-16 bg-gray-50 rounded-lg">
              <p className="text-gray-500">لا توجد فنادق مضافة حالياً.</p>
            </div>
          )}
        </div>
      </div>
    </Card>
  );
};

export default HotelsScreen;