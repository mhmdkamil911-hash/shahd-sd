import React from 'react';

const SaudiFlagIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 90 60"
    {...props}
  >
    <rect width="90" height="60" fill="#006c35" />
    <path
      fill="#FFFFFF"
      stroke="#FFFFFF"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
      d="M 15,42 C 35,36 60,36 80,42 L 75,46 C 55,40 30,40 10,46 L 15,42"
    />
  </svg>
);

export default SaudiFlagIcon;
