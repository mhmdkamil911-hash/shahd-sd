import React from 'react';

const SudanFlagIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 900 450"
    width="900"
    height="450"
    {...props}
  >
    <rect width="900" height="450" fill="#FFF" />
    <rect width="900" height="300" fill="#000" />
    <rect width="900" height="150" fill="#D21034" />
    <path d="M0 0v450l225-225L0 0z" fill="#00732F" />
  </svg>
);

export default SudanFlagIcon;
