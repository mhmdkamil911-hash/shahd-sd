import React from 'react';

const SteeringWheelIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    {...props}
  >
    <circle cx="12" cy="12" r="10" />
    <circle cx="12" cy="12" r="2" />
    <path d="M12 14v8" />
    <path d="M12 2v2" />
    <path d="M20.39 10.39 15 15" />
    <path d="M3.61 10.39 9 15" />
  </svg>
);

export default SteeringWheelIcon;
