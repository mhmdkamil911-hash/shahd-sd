import React, { useState } from 'react';
import { SAUDI_CITIES } from '../constants';
import { Trip } from '../types';
import Card from './ui/Card';
import Input from './ui/Input';
import Button from './ui/Button';
import Select from './ui/Select';
import ArrowRightIcon from './icons/ArrowRightIcon';

interface PostTripFormProps {
  onBack: () => void;
  // FIX: Added 'driverProfilePictureUrl' to Omit to match the data structure being passed.
  onSubmit: (data: Omit<Trip, 'id' | 'driverId' | 'driverName' | 'driverMobile' | 'carInfo' | 'carPictureFrontUrl' | 'driverProfilePictureUrl'>) => void;
}

const PostTripForm: React.FC<PostTripFormProps> = ({ onBack, onSubmit }) => {
  const [formData, setFormData] = useState({
    from: SAUDI_CITIES[0],
    to: SAUDI_CITIES[1],
    date: '',
    time: '',
    seats: 1,
    price: 100,
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    setFormData(prev => ({ 
        ...prev, 
        [name]: type === 'number' ? parseInt(value, 10) : value 
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.from === formData.to) {
        alert('مدينة الانطلاق والوصول لا يمكن أن تكونا متطابقتين.');
        return;
    }
    onSubmit(formData);
  };

  return (
    <Card className="max-w-lg mx-auto">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-sky-600">إضافة رحلة جديدة</h2>
        <button onClick={onBack} className="text-gray-500 hover:text-gray-700">
            <ArrowRightIcon className="w-6 h-6" />
        </button>
      </div>
      <p className="text-gray-600 mb-6 -mt-4 text-sm">سيتم استخدام معلوماتك المسجلة (الاسم، الجوال، السيارة) لهذه الرحلة.</p>
      <form onSubmit={handleSubmit} className="space-y-4">
        <h3 className="font-bold text-gray-800 border-b pb-2 pt-4">تفاصيل الرحلة</h3>
         <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Select name="from" label="الانطلاق من" value={formData.from} onChange={handleChange}>
                {SAUDI_CITIES.map(city => <option key={city} value={city}>{city}</option>)}
            </Select>
            <Select name="to" label="الوصول إلى" value={formData.to} onChange={handleChange}>
                {SAUDI_CITIES.map(city => <option key={city} value={city}>{city}</option>)}
            </Select>
        </div>
         <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Input name="date" type="date" label="تاريخ الرحلة" onChange={handleChange} required />
            <Input name="time" type="time" label="وقت الانطلاق" onChange={handleChange} required />
        </div>
         <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Input name="seats" type="number" label="المقاعد المتاحة" min="1" max="10" value={formData.seats} onChange={handleChange} required />
            <Input name="price" type="number" label="السعر للمقعد (ريال)" min="0" value={formData.price} onChange={handleChange} required />
        </div>

        <Button type="submit" className="w-full !mt-6">نشر الرحلة</Button>
      </form>
    </Card>
  );
};

export default PostTripForm;