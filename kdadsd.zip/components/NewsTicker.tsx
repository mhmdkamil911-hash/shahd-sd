import React, { useMemo } from 'react';
import { NewsItem } from '../types';
import MegaphoneIcon from './icons/MegaphoneIcon';

interface NewsTickerProps {
    items: NewsItem[];
}

const NewsTicker: React.FC<NewsTickerProps> = ({ items }) => {
    const newsString = useMemo(() => {
        return items.map(item => item.text).join(' ••• ');
    }, [items]);

    return (
        <section className="bg-gray-800/80 backdrop-blur-sm text-white rounded-lg shadow-md overflow-hidden flex items-center mb-8">
            <div className="bg-sky-600 p-3 flex-shrink-0">
                <MegaphoneIcon className="w-6 h-6" />
            </div>
            <div className="flex-grow overflow-hidden relative h-12">
                <div className="absolute inset-y-0 flex items-center">
                    {/* Animate two instances for a seamless loop */}
                    <p className="animate-marquee whitespace-nowrap px-4 font-medium text-lg">
                        {newsString}
                    </p>
                    <p className="animate-marquee whitespace-nowrap px-4 font-medium text-lg" aria-hidden="true">
                        {newsString}
                    </p>
                </div>
            </div>
        </section>
    );
};

export default NewsTicker;
