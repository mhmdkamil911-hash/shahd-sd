import React from 'react';
import { Trip } from '../types';
import Button from './ui/Button';
import WhatsAppIcon from './icons/WhatsAppIcon';
import PhoneIcon from './icons/PhoneIcon';

interface BookingModalProps {
  trip: Trip;
  onClose: () => void;
  onConfirmBooking: (tripId: string) => void;
}

const BookingModal: React.FC<BookingModalProps> = ({ trip, onClose, onConfirmBooking }) => {
  const handleConfirm = () => {
    onConfirmBooking(trip.id);
  };

  // Format phone number for WhatsApp link (e.g., remove leading 0, add KSA country code)
  const whatsappNumber = `+966${trip.driverMobile.substring(1)}`;

  return (
    <div 
      className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4"
      onClick={onClose}
    >
      <div 
        className="bg-white rounded-xl shadow-2xl p-6 sm:p-8 w-full max-w-md text-center transform transition-all animate-fade-in-up"
        onClick={(e) => e.stopPropagation()}
      >
        <h2 className="text-2xl font-bold text-sky-600 mb-2">خطوات حجز رحلتك</h2>
        <p className="text-gray-600 mb-6">
            لحجز مقعدك في الرحلة من <span className="font-bold">{trip.from}</span> إلى <span className="font-bold">{trip.to}</span>، يرجى اتباع الخطوات التالية:
        </p>

        {/* Step 1: Contact Driver */}
        <div className="bg-gray-50 p-4 rounded-lg mb-4 text-right">
            <h3 className="font-bold text-lg text-gray-800 mb-3">1. تواصل مع السائق أولاً</h3>
            <div className="flex items-center justify-between mb-3">
                <span className="font-semibold">اسم السائق:</span>
                <span className="font-bold text-gray-900">{trip.driverName}</span>
            </div>
            <div className="flex items-center justify-between">
                 <span className="font-semibold">رقم الجوال:</span>
                 <span className="font-mono tracking-wider text-gray-900">{trip.driverMobile}</span>
            </div>
            <div className="grid grid-cols-2 gap-3 mt-4">
                <a 
                    href={`https://wa.me/${whatsappNumber}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-center gap-2 w-full bg-green-500 text-white font-bold py-2 px-4 rounded-lg hover:bg-green-600 transition duration-300"
                >
                    <WhatsAppIcon className="w-5 h-5" />
                    <span>واتساب</span>
                </a>
                <a 
                    href={`tel:${trip.driverMobile}`}
                    className="flex items-center justify-center gap-2 w-full bg-sky-500 text-white font-bold py-2 px-4 rounded-lg hover:bg-sky-600 transition duration-300"
                >
                    <PhoneIcon className="w-5 h-5" />
                    <span>اتصال</span>
                </a>
            </div>
        </div>

        {/* Step 2: Confirm Booking */}
        <div className="bg-sky-50 p-4 rounded-lg mb-6">
            <h3 className="font-bold text-lg text-gray-800 mb-2">2. قم بتأكيد حجزك</h3>
            <p className="text-sm text-gray-600 mb-4">بعد الاتفاق مع السائق، اضغط على الزر أدناه لتأكيد الحجز وتسجيل الرحلة في حسابك.</p>
            <Button
                onClick={handleConfirm}
                className="w-full bg-sky-600 text-white font-bold py-3 px-4 rounded-lg hover:bg-sky-700"
            >
                تأكيد الحجز الآن
            </Button>
        </div>

        <Button
            onClick={onClose}
            className="w-full bg-transparent text-gray-600 hover:bg-gray-100 font-semibold !py-2"
        >
            إغلاق
        </Button>
      </div>
    </div>
  );
};

export default BookingModal;
