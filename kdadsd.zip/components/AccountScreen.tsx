import React, { useMemo } from 'react';
import { User, Booking, Trip, DriverData, UserRole, Parcel } from '../types';
import Card from './ui/Card';
import ArrowRightIcon from './icons/ArrowRightIcon';
import LogoutIcon from './icons/LogoutIcon';
import BoxIcon from './icons/BoxIcon';

interface AccountScreenProps {
  currentUser: User;
  bookings: Booking[];
  parcels: Parcel[];
  trips: Trip[];
  drivers: DriverData[];
  users: User[];
  onLogout: () => void;
  onBack: () => void;
}

const InfoRow: React.FC<{ label: string; value: string }> = ({ label, value }) => (
    <p className="text-sm"><span className="font-semibold text-gray-600">{label}:</span> {value}</p>
);

const AccountScreen: React.FC<AccountScreenProps> = ({ currentUser, bookings, parcels, trips, drivers, users, onLogout, onBack }) => {

    const passengerHistory = useMemo(() => {
        if (currentUser.role !== UserRole.PASSENGER) return [];

        const bookingItems = bookings
            .filter(b => b.passengerId === currentUser.id)
            .map(booking => {
                const trip = trips.find(t => t.id === booking.tripId);
                const driverData = drivers.find(d => d.id === trip?.driverId);
                const driverUser = users.find(u => u.id === driverData?.userId);
                return { 
                    type: 'booking' as const, 
                    date: trip?.date || booking.bookingDate,
                    id: booking.id,
                    trip, 
                    driver: driverUser && driverData ? { ...driverData, ...driverUser } : null 
                };
            });

        const parcelItems = parcels
            .filter(p => p.passengerId === currentUser.id)
            .map(parcel => {
                const trip = trips.find(t => t.id === parcel.tripId);
                const driverData = drivers.find(d => d.id === trip?.driverId);
                const driverUser = users.find(u => u.id === driverData?.userId);
                return { 
                    type: 'parcel' as const,
                    date: trip?.date || parcel.confirmationDate,
                    id: parcel.id,
                    trip,
                    driver: driverUser && driverData ? { ...driverData, ...driverUser } : null 
                };
            });

        return [...bookingItems, ...parcelItems]
            .filter(item => item.trip && item.driver)
            .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

    }, [bookings, parcels, trips, drivers, users, currentUser]);

    const driverTripHistory = useMemo(() => {
        if (currentUser.role !== UserRole.DRIVER) return [];
        const driverProfile = drivers.find(d => d.userId === currentUser.id);
        if (!driverProfile) return [];

        return trips
            .filter(t => t.driverId === driverProfile.id)
            .map(trip => {
                const tripBookings = bookings.filter(b => b.tripId === trip.id);
                const passengers = tripBookings.map(b => users.find(u => u.id === b.passengerId)).filter(Boolean) as User[];
                
                const tripParcels = parcels
                    .filter(p => p.tripId === trip.id)
                    .map(p => {
                        const sender = users.find(u => u.id === p.passengerId);
                        return sender ? { ...p, sender } : null;
                    })
                    .filter(Boolean) as (Parcel & { sender: User })[];

                return { trip, passengers, parcels: tripParcels };
            })
            .sort((a, b) => new Date(b.trip.date).getTime() - new Date(a.trip.date).getTime());
    }, [trips, bookings, parcels, users, drivers, currentUser]);

    const currentDriverData = useMemo(() => {
        if (currentUser.role === UserRole.DRIVER) {
            return drivers.find(d => d.userId === currentUser.id);
        }
        return null;
    }, [drivers, currentUser]);

    return (
        <Card className="max-w-4xl mx-auto !bg-white/90 backdrop-blur-sm">
            <div className="flex items-center justify-between mb-6 border-b pb-4">
                <div className="flex items-center gap-3">
                     <img src={currentUser.profilePictureUrl} alt={currentUser.fullName} className="w-12 h-12 rounded-full object-cover border-2 border-sky-500" />
                    <h2 className="text-2xl font-bold text-sky-600">حسابي</h2>
                </div>
                 <div className="flex items-center gap-4">
                    <button onClick={onLogout} className="text-sm font-semibold text-red-500 hover:text-red-700 flex items-center gap-1.5 transition-colors">
                        <LogoutIcon className="w-5 h-5" />
                        <span>تسجيل الخروج</span>
                    </button>
                    <button onClick={onBack} className="text-gray-500 hover:text-gray-700">
                        <ArrowRightIcon className="w-6 h-6" />
                    </button>
                </div>
            </div>

            <div className="bg-gray-50 p-4 rounded-lg mb-8">
                <h3 className="font-bold text-lg text-gray-800">{currentUser.fullName}</h3>
                <p className="text-gray-600">{currentUser.mobile}</p>
                <p className="text-gray-600 text-sm">{currentUser.email}</p>
                <p className={`text-sm text-white px-2 py-0.5 rounded-full inline-block mt-2 ${currentUser.status === 'active' ? 'bg-green-500' : 'bg-amber-500'}`}>
                    {currentUser.status === 'active' ? 'الحساب مفعل' : 'الحساب قيد المراجعة'}
                </p>
            </div>
            
            {currentUser.role === UserRole.DRIVER && currentDriverData && (
                <div className="mb-8">
                    <h3 className="text-xl font-bold text-gray-800 mb-4">بيانات سيارتي</h3>
                    <div className="bg-white p-4 rounded-lg border">
                        <InfoRow label="السيارة" value={`${currentDriverData.carType} ${currentDriverData.carModel}`} />
                        <InfoRow label="اللون" value={currentDriverData.carColor} />
                        <InfoRow label="اللوحة" value={currentDriverData.plateNumber} />
                        <div className="flex gap-4 mt-4">
                            <img src={currentDriverData.carPictureFrontUrl} alt="أمامية" className="w-32 h-24 object-cover rounded-md" />
                            <img src={currentDriverData.carPictureRearUrl} alt="خلفية" className="w-32 h-24 object-cover rounded-md" />
                        </div>
                    </div>
                </div>
            )}

            <h3 className="text-xl font-bold text-gray-800 mb-4">سجل العمليات</h3>

            {currentUser.role === UserRole.PASSENGER && (
                passengerHistory.length > 0 ? (
                    <div className="space-y-4 max-h-[60vh] overflow-y-auto pr-2">
                        {passengerHistory.map(item => {
                            if (!item.trip || !item.driver) return null;
                            const { trip, driver } = item;
                            const isBooking = item.type === 'booking';
                            
                            return (
                                <div key={item.id} className={`p-4 rounded-lg border ${isBooking ? 'bg-white' : 'bg-teal-50/50'}`}>
                                    <div className="flex justify-between items-start">
                                        <h4 className={`font-bold text-lg ${isBooking ? 'text-sky-700' : 'text-teal-700'}`}>{trip.from} ➔ {trip.to}</h4>
                                        <div className={`flex items-center gap-2 text-sm font-bold px-2 py-1 rounded-full ${isBooking ? 'bg-sky-100 text-sky-800' : 'bg-teal-100 text-teal-800'}`}>
                                            {isBooking ? 'حجز مقعد' : <><BoxIcon className="w-4 h-4"/><span>توصيل طرد</span></>}
                                        </div>
                                    </div>
                                    <InfoRow label="التاريخ" value={`${trip.date} - ${trip.time}`} />
                                    {isBooking && <InfoRow label="السعر المدفوع" value={`${trip.price} ريال`} />}
                                    <div className="mt-2 pt-2 border-t">
                                        <p className="text-sm font-bold text-gray-700 mb-1">معلومات السائق:</p>
                                        <InfoRow label="الاسم" value={driver.fullName || ''} />
                                        <InfoRow label="الجوال" value={driver.mobile || ''} />
                                        <InfoRow label="السيارة" value={`${driver.carType} ${driver.carModel} (${driver.carColor})`} />
                                        {driver.carPictureFrontUrl && <img src={driver.carPictureFrontUrl} alt="سيارة السائق" className="w-32 h-24 object-cover rounded-md mt-2"/>}
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                ) : <p className="text-gray-500 text-center py-8 bg-gray-50 rounded-lg">لا يوجد لديك عمليات سابقة.</p>
            )}

             {currentUser.role === UserRole.DRIVER && (
                driverTripHistory.length > 0 ? (
                    <div className="space-y-4 max-h-[60vh] overflow-y-auto pr-2">
                        {driverTripHistory.map(({ trip, passengers, parcels }) => (
                            <div key={trip.id} className="bg-white p-4 rounded-lg border">
                                <h4 className="font-bold text-sky-700 text-lg">{trip.from} ➔ {trip.to}</h4>
                                <InfoRow label="التاريخ" value={`${trip.date} - ${trip.time}`} />
                                <div className="mt-2 pt-2 border-t">
                                    <p className="text-sm font-bold text-gray-700 mb-1">
                                        الركاب ({passengers.length})
                                    </p>
                                    {passengers.length > 0 ? (
                                        <ul className="space-y-1">
                                          {passengers.map(p => (
                                            <li key={p.id} className="text-sm flex items-center gap-4 bg-gray-50 p-2 rounded">
                                                <span className="flex-grow">{p.fullName}</span>
                                                <span className="text-gray-600">{p.mobile}</span>
                                            </li>
                                          ))}
                                        </ul>
                                    ) : <p className="text-xs text-gray-500">لم يتم تسجيل ركاب لهذه الرحلة.</p>}
                                </div>
                                {parcels.length > 0 && (
                                    <div className="mt-2 pt-2 border-t">
                                        <p className="text-sm font-bold text-teal-700 mb-1 flex items-center gap-1.5">
                                            <BoxIcon className="w-4 h-4"/>
                                            الطرود ({parcels.length})
                                        </p>
                                        <ul className="space-y-1">
                                          {parcels.map(p => (
                                            <li key={p.id} className="text-sm flex items-center gap-4 bg-teal-50 p-2 rounded">
                                                <span className="flex-grow">طرد من: <span className="font-semibold">{p.sender.fullName}</span></span>
                                                <span className="text-gray-600">{p.sender.mobile}</span>
                                            </li>
                                          ))}
                                        </ul>
                                    </div>
                                )}
                            </div>
                        ))}
                    </div>
                ) : <p className="text-gray-500 text-center py-8 bg-gray-50 rounded-lg">لا يوجد لديك رحلات منشورة.</p>
            )}

        </Card>
    );
};

export default AccountScreen;
