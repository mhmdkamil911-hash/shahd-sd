import React, { useState } from 'react';
import { GoogleGenAI, Modality } from '@google/genai';
import Card from './ui/Card';
import Button from './ui/Button';
import Input from './ui/Input';
import ArrowRightIcon from './icons/ArrowRightIcon';
import ImageIcon from './icons/ImageIcon';
import MagicWandIcon from './icons/MagicWandIcon';

interface ImageEditorScreenProps {
  onBack: () => void;
}

const fileToBase64 = (file: File): Promise<string> => new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve((reader.result as string).split(',')[1]);
    reader.onerror = error => reject(error);
});

const ImageEditorScreen: React.FC<ImageEditorScreenProps> = ({ onBack }) => {
    const [originalImage, setOriginalImage] = useState<string | null>(null);
    const [imageFile, setImageFile] = useState<File | null>(null);
    const [editedImage, setEditedImage] = useState<string | null>(null);
    const [prompt, setPrompt] = useState<string>('');
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);

    const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            if (file.size > 4 * 1024 * 1024) { // Check for 4MB size limit
                setError("حجم الصورة كبير جداً. الرجاء اختيار صورة أصغر من 4 ميجابايت.");
                return;
            }
            setImageFile(file);
            const reader = new FileReader();
            reader.onloadend = () => {
                setOriginalImage(reader.result as string);
                setEditedImage(null);
                setError(null);
            };
            reader.readAsDataURL(file);
        }
    };

    const handleGenerate = async () => {
        if (!imageFile || !prompt) {
            setError('الرجاء رفع صورة وكتابة وصف للتعديل.');
            return;
        }

        setIsLoading(true);
        setError(null);
        setEditedImage(null);

        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            const base64Data = await fileToBase64(imageFile);

            const imagePart = {
                inlineData: {
                    mimeType: imageFile.type,
                    data: base64Data,
                },
            };
            const textPart = { text: prompt };

            const response = await ai.models.generateContent({
                model: 'gemini-2.5-flash-image',
                contents: { parts: [imagePart, textPart] },
                config: {
                    responseModalities: [Modality.IMAGE],
                },
            });

            const firstPart = response.candidates?.[0]?.content?.parts?.[0];
            if (firstPart?.inlineData) {
                const base64ImageBytes = firstPart.inlineData.data;
                const mimeType = firstPart.inlineData.mimeType;
                setEditedImage(`data:${mimeType};base64,${base64ImageBytes}`);
            } else {
                 let errorMessage = 'لم يتمكن النموذج من إنشاء صورة. قد يكون السبب طلب غير آمن أو غير مدعوم.';
                 if (response?.candidates?.[0]?.finishReason) {
                     errorMessage += ` (السبب: ${response.candidates[0].finishReason})`;
                 }
                throw new Error(errorMessage);
            }
        } catch (err: any) {
            console.error(err);
            setError(err.message || 'حدث خطأ أثناء معالجة الصورة. الرجاء المحاولة مرة أخرى.');
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <Card className="max-w-7xl !bg-white/90 backdrop-blur-sm">
            <div className="flex items-center justify-between mb-6 border-b pb-4">
                <div className="flex items-center gap-3">
                    <MagicWandIcon className="w-8 h-8 text-sky-600" />
                    <h2 className="text-2xl font-bold text-sky-600">محرر الصور بالذكاء الاصطناعي</h2>
                </div>
                <button onClick={onBack} className="text-gray-500 hover:text-gray-700">
                    <ArrowRightIcon className="w-6 h-6" />
                </button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
                {/* Controls Column */}
                <div className="space-y-6">
                    <div>
                        <label htmlFor="image-upload" className="block text-lg font-bold text-gray-800 mb-2">
                            1. ارفع صورتك
                        </label>
                        <div className="mt-2 flex justify-center rounded-lg border border-dashed border-gray-900/25 px-6 py-10 bg-gray-50">
                            <div className="text-center">
                                <ImageIcon className="mx-auto h-12 w-12 text-gray-400" aria-hidden="true" />
                                <div className="mt-4 flex text-sm leading-6 text-gray-600">
                                <label
                                    htmlFor="image-upload"
                                    className="relative cursor-pointer rounded-md bg-white font-semibold text-sky-600 focus-within:outline-none focus-within:ring-2 focus-within:ring-sky-600 focus-within:ring-offset-2 hover:text-sky-500"
                                >
                                    <span>اختر ملف</span>
                                    <input id="image-upload" name="image-upload" type="file" className="sr-only" accept="image/png, image/jpeg" onChange={handleImageChange} />
                                </label>
                                <p className="pr-1">أو اسحبها وأفلتها هنا</p>
                                </div>
                                <p className="text-xs leading-5 text-gray-600">PNG, JPG up to 4MB</p>
                            </div>
                        </div>
                    </div>

                    <div>
                        <Input 
                            label="2. اكتب وصف التعديل" 
                            name="prompt" 
                            placeholder="مثال: أضف فلتر قديم، اجعل السماء أكثر زرقة..."
                            value={prompt}
                            onChange={(e) => setPrompt(e.target.value)}
                            disabled={!originalImage || isLoading}
                        />
                    </div>
                     <Button 
                        onClick={handleGenerate}
                        disabled={!originalImage || !prompt || isLoading}
                        className="w-full !text-lg disabled:bg-gray-400 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                    >
                       {isLoading ? (
                           <>
                            <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg>
                            <span>جاري التعديل...</span>
                           </>
                       ) : (
                           <>
                            <MagicWandIcon className="w-5 h-5"/>
                            <span>نفذ التعديل</span>
                           </>
                       )}
                    </Button>
                    {error && <p className="text-red-500 text-sm text-center pt-2">{error}</p>}
                </div>

                {/* Image Display Column */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-center bg-gray-100 p-4 rounded-lg min-h-[300px]">
                    <div className="text-center">
                        <h3 className="font-bold text-gray-700 mb-2">الأصلية</h3>
                        <div className="aspect-square bg-gray-200 rounded-md flex items-center justify-center overflow-hidden">
                        {originalImage ? (
                            <img src={originalImage} alt="Original" className="w-full h-full object-contain" />
                        ) : (
                            <span className="text-gray-500">لم يتم رفع صورة</span>
                        )}
                        </div>
                    </div>
                     <div className="text-center">
                        <h3 className="font-bold text-gray-700 mb-2">المعدّلة</h3>
                         <div className="aspect-square bg-gray-200 rounded-md flex items-center justify-center overflow-hidden">
                        {isLoading ? (
                             <svg className="animate-spin h-10 w-10 text-sky-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg>
                        ) : editedImage ? (
                            <img src={editedImage} alt="Edited" className="w-full h-full object-contain" />
                        ) : (
                            <span className="text-gray-500">بانتظار التعديل</span>
                        )}
                        </div>
                    </div>
                </div>
            </div>
        </Card>
    );
};

export default ImageEditorScreen;
