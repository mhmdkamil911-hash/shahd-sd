import React, { useState, useMemo } from 'react';
import { DriverData, Trip, Hotel, NewsItem, GalleryImage, User, UserStatus, SudaneseGathering, UserRole } from '../types';
import Card from './ui/Card';
import Button from './ui/Button';
import Input from './ui/Input';
import FileInput from './ui/FileInput';
import ArrowRightIcon from './icons/ArrowRightIcon';
import TrashIcon from './icons/TrashIcon';
import LogoutIcon from './icons/LogoutIcon';
import ShieldCheckIcon from './icons/ShieldCheckIcon';

interface AdminDashboardProps {
  users: User[];
  drivers: DriverData[];
  trips: Trip[];
  hotels: Hotel[];
  gatherings: SudaneseGathering[];
  newsItems: NewsItem[];
  galleryImages: GalleryImage[];
  onUserStatusUpdate: (userId: string, status: UserStatus) => void;
  onUserRoleUpdate: (userId: string, role: UserRole) => void;
  onDeleteTrip: (tripId: string) => void;
  onDeleteHotel: (hotelId: string) => void;
  onDeleteGathering: (gatheringId: string) => void;
  onAddNewsItem: (text: string) => void;
  onDeleteNewsItem: (newsId: string) => void;
  onAddGalleryImage: (imageUrl: string) => void;
  onDeleteGalleryImage: (imageId: string) => void;
  onSetBackground: (imageUrl: string) => void;
  onRestoreDefaultBackground: () => void;
  onBack: () => void;
  onLogout: () => void;
}

const fileToBase64 = (file: File): Promise<string> => new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = error => reject(error);
});

const InfoRow: React.FC<{ label: string, value: React.ReactNode }> = ({ label, value }) => (
    <p className="text-sm text-gray-600 truncate"><span className="font-semibold text-gray-800">{label}:</span> {value}</p>
);

type AdminTab = 'users' | 'content' | 'data';
type UserFilter = 'all' | 'pending' | 'active' | 'rejected' | 'drivers' | 'passengers' | 'moderators';


const AdminDashboard: React.FC<AdminDashboardProps> = (props) => {
  const {
    users, drivers, trips, hotels, gatherings, newsItems, galleryImages,
    onUserStatusUpdate, onUserRoleUpdate, onDeleteTrip, onDeleteHotel, onDeleteGathering, onAddNewsItem, onDeleteNewsItem,
    onAddGalleryImage, onDeleteGalleryImage, onSetBackground, onRestoreDefaultBackground,
    onBack, onLogout
  } = props;
  
  const [activeTab, setActiveTab] = useState<AdminTab>('users');
  const [newsText, setNewsText] = useState('');
  const [isUploading, setIsUploading] = useState(false);
  const [userFilter, setUserFilter] = useState<UserFilter>('pending');

  const filteredUsers = useMemo(() => {
    return users.filter(user => {
      if (user.role === UserRole.ADMIN) return false; // Exclude admin from list
      switch (userFilter) {
        case 'pending': return user.status === 'pending';
        case 'active': return user.status === 'active';
        case 'rejected': return user.status === 'rejected';
        case 'drivers': return user.role === UserRole.DRIVER;
        case 'passengers': return user.role === UserRole.PASSENGER;
        case 'moderators': return user.role === UserRole.MODERATOR;
        case 'all':
        default:
          return true;
      }
    });
  }, [users, userFilter]);

  const handleRoleChange = (user: User) => {
      if (user.role === UserRole.MODERATOR) {
          if (window.confirm(`هل أنت متأكد من إلغاء دور الإشراف للمستخدم ${user.fullName}؟`)) {
              const isDriver = drivers.some(d => d.userId === user.id);
              onUserRoleUpdate(user.id, isDriver ? UserRole.DRIVER : UserRole.PASSENGER);
          }
      } else {
          if (window.confirm(`هل أنت متأكد من ترقية المستخدم ${user.fullName} إلى مشرف؟`)) {
              onUserRoleUpdate(user.id, UserRole.MODERATOR);
          }
      }
  };

  const handleAddNews = () => {
    if (newsText.trim()) {
      onAddNewsItem(newsText.trim());
      setNewsText('');
    }
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      setIsUploading(true);
      try {
        const uploadPromises = Array.from(files).map(file => fileToBase64(file));
        const base64Images = await Promise.all(uploadPromises);
        base64Images.forEach(base64Image => {
          onAddGalleryImage(base64Image);
        });
      } catch (error) {
        console.error("Error converting files to base64", error);
        alert("حدث خطأ أثناء رفع الصور.");
      } finally {
        setIsUploading(false);
        e.target.value = ''; // Reset file input to allow re-uploading the same file(s)
      }
    }
  };

  const handleBackgroundUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
        try {
            const base64Image = await fileToBase64(file);
            onSetBackground(base64Image);
        } catch (error) {
            console.error("Error converting background file", error);
            alert("حدث خطأ أثناء رفع الخلفية.");
        }
    }
  };
  
  const TabButton: React.FC<{ tab: AdminTab; label: string; count?: number }> = ({ tab, label, count }) => (
      <button 
        onClick={() => setActiveTab(tab)}
        className={`px-4 py-2 text-sm font-semibold rounded-t-lg transition-colors ${activeTab === tab ? 'bg-white text-sky-600 border-b-2 border-sky-600' : 'bg-transparent text-gray-500 hover:bg-gray-100'}`}
      >
        {label} {typeof count !== 'undefined' && <span className={`ml-1 px-2 py-0.5 rounded-full text-xs ${activeTab === tab ? 'bg-sky-600 text-white' : 'bg-gray-200 text-gray-700'}`}>{users.filter(u => u.status === 'pending').length}</span>}
      </button>
  );

  const UserFilterButton: React.FC<{ filter: UserFilter; label: string }> = ({ filter, label }) => (
    <button onClick={() => setUserFilter(filter)} className={`px-3 py-1 text-xs font-semibold rounded-full ${userFilter === filter ? 'bg-sky-600 text-white' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'}`}>
      {label}
    </button>
  );

  const getRoleText = (role: UserRole) => {
    switch (role) {
      case UserRole.DRIVER: return 'سائق';
      case UserRole.PASSENGER: return 'راكب';
      case UserRole.MODERATOR: return 'مشرف';
      default: return role;
    }
  };

  const getStatusPill = (status: UserStatus) => {
      switch (status) {
          case 'active': return <span className="px-2 py-0.5 text-xs font-semibold text-green-800 bg-green-100 rounded-full">نشط</span>;
          case 'pending': return <span className="px-2 py-0.5 text-xs font-semibold text-amber-800 bg-amber-100 rounded-full">معلق</span>;
          case 'rejected': return <span className="px-2 py-0.5 text-xs font-semibold text-red-800 bg-red-100 rounded-full">مرفوض</span>;
      }
  };

  return (
    <Card className="max-w-full">
       <div className="flex items-center justify-between mb-2">
        <h2 className="text-2xl font-bold text-sky-600">لوحة الإدارة</h2>
        <div className="flex items-center gap-4">
            <button onClick={onLogout} className="text-sm font-semibold text-red-500 hover:text-red-700 flex items-center gap-1.5 transition-colors">
                <LogoutIcon className="w-5 h-5" />
                <span>تسجيل الخروج</span>
            </button>
            <button onClick={onBack} className="text-gray-500 hover:text-gray-700">
                <ArrowRightIcon className="w-6 h-6" />
            </button>
        </div>
      </div>
      
      <div className="border-b border-gray-200 mb-6">
          <nav className="-mb-px flex space-x-4">
              <TabButton tab="users" label="إدارة المستخدمين" count={users.filter(u => u.status === 'pending').length} />
              <TabButton tab="content" label="إدارة المحتوى" />
              <TabButton tab="data" label="البيانات العامة" />
          </nav>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {activeTab === 'users' && (
             <div className="lg:col-span-3 space-y-4">
                 <h3 className="text-xl font-bold text-gray-800">قائمة المستخدمين</h3>
                 <div className="flex flex-wrap items-center gap-2 pb-4 border-b">
                    <UserFilterButton filter="pending" label="معلق" />
                    <UserFilterButton filter="active" label="نشط" />
                    <UserFilterButton filter="rejected" label="مرفوض" />
                    <UserFilterButton filter="all" label="الكل" />
                    <span className="border-l h-5 mx-2"></span>
                    <UserFilterButton filter="drivers" label="السائقين" />
                    <UserFilterButton filter="passengers" label="الركاب" />
                    <UserFilterButton filter="moderators" label="المشرفين" />
                 </div>
                 {filteredUsers.length === 0 ? (
                    <p className="text-gray-500 bg-gray-50 p-4 rounded-lg">لا يوجد مستخدمون يطابقون هذا الفلتر.</p>
                 ) : (
                    <div className="space-y-4 max-h-[70vh] overflow-y-auto pr-2">
                        {filteredUsers.map(user => {
                            const driver = drivers.find(d => d.userId === user.id);
                            return (
                                <div key={user.id} className="bg-white p-4 rounded-lg border border-gray-200 shadow-sm">
                                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-4">
                                        {/* User Info */}
                                        <div className="space-y-2">
                                            <div className="flex items-center gap-3">
                                               <img src={user.profilePictureUrl} className="w-12 h-12 object-cover rounded-full border-2 border-gray-200" alt="شخصية"/>
                                                <div>
                                                    <p className="font-bold text-gray-800">{user.fullName}</p>
                                                    <p className="text-sm text-gray-500">{user.mobile}</p>
                                                </div>
                                            </div>
                                            <div className="flex items-center gap-2 pt-2">
                                                {getStatusPill(user.status)}
                                                <span className="px-2 py-0.5 text-xs font-semibold text-sky-800 bg-sky-100 rounded-full">{getRoleText(user.role)}</span>
                                            </div>
                                        </div>
                                        {/* Documents and Driver Info */}
                                        <div className="space-y-2">
                                            {driver && (
                                                <>
                                                  <InfoRow label="السيارة" value={`${driver.carType} ${driver.carModel}`} />
                                                  <InfoRow label="اللوحة" value={driver.plateNumber} />
                                                </>
                                            )}
                                            <div className="flex items-center gap-2">
                                                <a href={user.residencePermitUrl} target="_blank" rel="noopener noreferrer" className="text-sm text-sky-600 hover:underline">عرض الإقامة</a>
                                                 {driver && <a href={driver.carPictureFrontUrl} target="_blank" rel="noopener noreferrer" className="text-sm text-sky-600 hover:underline">عرض السيارة</a>}
                                            </div>
                                        </div>
                                        {/* Actions */}
                                        <div className="flex items-center justify-end gap-3 self-start">
                                            {user.status === 'pending' && (
                                                <>
                                                    <Button onClick={() => onUserStatusUpdate(user.id, 'active')} className="bg-green-500 hover:bg-green-600 !py-1.5 !px-3 text-sm">موافقة</Button>
                                                    <Button onClick={() => onUserStatusUpdate(user.id, 'rejected')} className="bg-red-500 hover:bg-red-600 !py-1.5 !px-3 text-sm">رفض</Button>
                                                </>
                                            )}
                                            <Button onClick={() => handleRoleChange(user)} className="bg-indigo-500 hover:bg-indigo-600 !py-1.5 !px-3 text-sm flex items-center gap-1.5">
                                              <ShieldCheckIcon className="w-4 h-4" />
                                              <span>{user.role === UserRole.MODERATOR ? 'إلغاء الإشراف' : 'ترقية لمشرف'}</span>
                                            </Button>
                                        </div>
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                 )}
            </div>
        )}

        {activeTab === 'content' && (
          <>
            <div className="space-y-8 lg:col-span-2">
                <h3 className="text-xl font-bold text-gray-800 mb-4 border-b pb-2">إدارة المحتوى الرئيسي</h3>
                 <div>
                    <h4 className="text-lg font-semibold text-gray-700 mb-3">إدارة خلفية التطبيق</h4>
                    <div className="space-y-2">
                        <FileInput name="backgroundImage" label="تغيير صورة الخلفية" onChange={handleBackgroundUpload} accept="image/*" />
                        <Button onClick={onRestoreDefaultBackground} className="!py-1.5 !px-3 text-sm w-full bg-gray-600 hover:bg-gray-700">
                            استعادة الخلفية الافتراضية
                        </Button>
                    </div>
                </div>
                <div>
                    <h4 className="text-lg font-semibold text-gray-700 mb-3">الشريط الإخباري</h4>
                    <div className="flex gap-2">
                        <Input name="newsText" label="" placeholder="أضف خبراً جديداً..." value={newsText} onChange={(e) => setNewsText(e.target.value)} />
                        <Button onClick={handleAddNews} className="!py-2">إضافة</Button>
                    </div>
                    <div className="mt-4 space-y-2 max-h-[25vh] overflow-y-auto pr-2">
                        {newsItems.map(item => (
                            <div key={item.id} className="flex justify-between items-center bg-gray-100 p-2 rounded">
                                <p className="text-sm text-gray-800 truncate">{item.text}</p>
                                <button onClick={() => onDeleteNewsItem(item.id)} className="text-red-500 hover:text-red-700"><TrashIcon className="w-4 h-4"/></button>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
            <div className="space-y-8 lg:col-span-1">
                 <h3 className="text-xl font-bold text-gray-800 mb-4 border-b pb-2">معرض الصور</h3>
                 <FileInput name="galleryImage" label="رفع صور جديدة للمعرض" onChange={handleImageUpload} accept="image/*" disabled={isUploading} multiple />
                {isUploading && <p className="text-sm text-sky-600 mt-2">جاري الرفع...</p>}
                <div className="mt-4 grid grid-cols-2 gap-4 max-h-[40vh] overflow-y-auto pr-2">
                    {galleryImages.map(image => (
                        <div key={image.id} className="relative group">
                            <img src={image.imageUrl} alt="Gallery item" className="w-full h-24 object-cover rounded-md" />
                            <div className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                                <button onClick={() => onDeleteGalleryImage(image.id)} className="text-white p-2 bg-red-500 rounded-full hover:bg-red-600">
                                    <TrashIcon className="w-5 h-5"/>
                                </button>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
          </>
        )}
        
        {activeTab === 'data' && (
          <>
            <div className="space-y-8 lg:col-span-1">
                <h3 className="text-xl font-bold text-gray-800 mb-4">الرحلات المنشورة ({trips.length})</h3>
                {trips.length === 0 ? <p className="text-gray-500 bg-gray-50 p-4 rounded-lg">لا توجد رحلات منشورة حالياً.</p> : (
                  <div className="space-y-4 max-h-[70vh] overflow-y-auto pr-2">
                    {trips.map((trip) => (
                      <div key={trip.id} className="bg-gray-50 p-3 rounded-lg border relative">
                        <button onClick={() => onDeleteTrip(trip.id)} className="absolute top-2 left-2 text-gray-400 hover:text-red-500 transition-colors"><TrashIcon className="w-4 h-4" /></button>
                        <InfoRow label="السائق" value={trip.driverName} />
                        <InfoRow label="من" value={`${trip.from} > ${trip.to}`} />
                        <InfoRow label="التاريخ" value={`${trip.date} - ${trip.time}`} />
                        <InfoRow label="السعر" value={<span className="font-bold text-green-600">{trip.price} ريال</span>} />
                      </div>
                    ))}
                  </div>
                )}
            </div>
            <div className="space-y-8 lg:col-span-1">
                <h3 className="text-xl font-bold text-gray-800 mb-4">الفنادق المضافة ({hotels.length})</h3>
                {hotels.length === 0 ? <p className="text-gray-500 bg-gray-50 p-4 rounded-lg">لا توجد فنادق مضافة حالياً.</p> : (
                  <div className="space-y-4 max-h-[70vh] overflow-y-auto pr-2">
                    {hotels.map((hotel) => (
                      <div key={hotel.id} className="bg-gray-50 p-3 rounded-lg border relative">
                        <button onClick={() => onDeleteHotel(hotel.id)} className="absolute top-2 left-2 text-gray-400 hover:text-red-500 transition-colors"><TrashIcon className="w-4 h-4" /></button>
                        <InfoRow label="الفندق" value={hotel.name} />
                        <InfoRow label="للتواصل" value={hotel.contact} />
                      </div>
                    ))}
                  </div>
                )}
            </div>
             <div className="space-y-8 lg:col-span-1">
                <h3 className="text-xl font-bold text-gray-800 mb-4">تجمعات سودانية ({gatherings.length})</h3>
                {gatherings.length === 0 ? <p className="text-gray-500 bg-gray-50 p-4 rounded-lg">لا توجد تجمعات مضافة حالياً.</p> : (
                  <div className="space-y-4 max-h-[70vh] overflow-y-auto pr-2">
                    {gatherings.map((item) => (
                      <div key={item.id} className="bg-gray-50 p-3 rounded-lg border relative">
                        <button onClick={() => onDeleteGathering(item.id)} className="absolute top-2 left-2 text-gray-400 hover:text-red-500 transition-colors"><TrashIcon className="w-4 h-4" /></button>
                        <InfoRow label="الاسم" value={item.name} />
                        <InfoRow label="النوع" value={item.type === 'restaurant' ? 'مطعم' : item.type === 'shop' ? 'متجر' : 'آخر'} />
                        <InfoRow label="للتواصل" value={item.contact} />
                      </div>
                    ))}
                  </div>
                )}
            </div>
          </>
        )}
      </div>
    </Card>
  );
};

export default AdminDashboard;