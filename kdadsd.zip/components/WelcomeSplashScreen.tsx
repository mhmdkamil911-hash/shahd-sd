import React from 'react';
import Button from './ui/Button';

interface WelcomeSplashScreenProps {
  onDismiss: () => void;
}

const WelcomeSplashScreen: React.FC<WelcomeSplashScreenProps> = ({ onDismiss }) => {
  return (
    <div className="fixed inset-0 bg-gray-900/80 backdrop-blur-sm flex items-center justify-center z-50 transition-opacity duration-300 p-4">
      <div className="bg-white rounded-xl shadow-2xl p-6 sm:p-8 max-w-md text-center transform transition-all animate-fade-in-up">
        <h1 className="text-2xl font-bold text-sky-600 mb-4">
          🟢 مرحب بيك في كداد سوداني 🇸🇩🚗🇸🇦
        </h1>
        <div className="space-y-3 text-gray-700 text-base leading-relaxed">
            <p>
                أهلاً وسهلاً بيك في تطبيق كداد، منصّتك الذكية للتوصيل بين مدن السعودية بنظام التشارك في السيارة.
            </p>
            <p>
                📍 هنا تلقى السواقين والركّاب في مكان واحد — سافر بأمان، ووفّر في المشاوير، وعيش روح التعاون السودانية الحقيقية وين ما كنت!
            </p>
            <p>
                سواء كنت سائق داير تشارك مقاعد عربيتك، أو راكب داير تسافر براحة وسهولة، كداد جاهز يخدمك بخطوات بسيطة وسريعة.
            </p>
            <p className="font-semibold pt-2">
                🚘 ابدأ رحلتك اليوم…
            </p>
            <p>
                واختر مدينتك، وحدد وجهتك، والباقي علينا ✨
            </p>
        </div>
        <p className="mt-6 text-lg font-bold text-green-600">
            كداد سوداني– سواقة تجمعنا 💚
        </p>
        <Button onClick={onDismiss} className="w-full !text-lg mt-6">
          موافق
        </Button>
      </div>
    </div>
  );
};

export default WelcomeSplashScreen;
