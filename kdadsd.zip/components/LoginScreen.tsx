import React, { useState } from 'react';
import Card from './ui/Card';
import Input from './ui/Input';
import Button from './ui/Button';
import AdminIcon from './icons/AdminIcon';
import ArrowRightIcon from './icons/ArrowRightIcon';

interface AdminLoginScreenProps {
  onLogin: (username: string, password: string) => boolean;
  onBack: () => void;
}

const AdminLoginScreen: React.FC<AdminLoginScreenProps> = ({ onLogin, onBack }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (!username || !password) {
        setError('الرجاء إدخال اسم المستخدم وكلمة المرور.');
        return;
    }
    const success = onLogin(username, password);
    if (!success) {
      setError('بيانات الدخول غير صحيحة.');
    }
  };

  return (
    <Card className="max-w-md mx-auto">
       <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
              <AdminIcon className="w-8 h-8 text-sky-600" />
              <h2 className="text-2xl font-bold text-sky-600">دخول الإدارة</h2>
          </div>
          <button onClick={onBack} className="text-gray-500 hover:text-gray-700">
              <ArrowRightIcon className="w-6 h-6" />
          </button>
      </div>
      <p className="text-gray-600 mb-8">الرجاء إدخال بيانات الدخول للوصول إلى لوحة التحكم.</p>

      <form onSubmit={handleSubmit} className="space-y-4" noValidate>
        <Input
          name="username"
          label="اسم المستخدم"
          placeholder="ادخل اسم المستخدم"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          required
        />
        <Input
          name="password"
          type="password"
          label="كلمة المرور"
          placeholder="ادخل كلمة المرور"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        />
        {error && <p className="text-red-500 text-sm text-center pt-2">{error}</p>}
        <Button type="submit" className="w-full !mt-6">تسجيل الدخول</Button>
      </form>
    </Card>
  );
};

export default AdminLoginScreen;