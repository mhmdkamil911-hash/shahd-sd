import React from 'react';

interface CommonInputProps {
  label: string;
}

type InputProps = CommonInputProps & { as?: 'input' } & React.InputHTMLAttributes<HTMLInputElement>;
type TextareaProps = CommonInputProps & { as: 'textarea' } & React.TextareaHTMLAttributes<HTMLTextAreaElement>;

const Input: React.FC<InputProps | TextareaProps> = ({ label, name, as = 'input', ...props }) => {
  const commonClasses = "w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-sky-500 focus:border-sky-500 transition duration-150";

  const renderInput = () => {
    if (as === 'textarea') {
      return (
        <textarea
          id={name}
          name={name}
          className={commonClasses}
          rows={3}
          {...(props as React.TextareaHTMLAttributes<HTMLTextAreaElement>)}
        />
      );
    }
    return (
      <input
        id={name}
        name={name}
        className={commonClasses}
        {...(props as React.InputHTMLAttributes<HTMLInputElement>)}
      />
    );
  };

  return (
    <div>
      <label htmlFor={name} className="block text-sm font-medium text-gray-700 mb-1">
        {label}
      </label>
      {renderInput()}
    </div>
  );
};

export default Input;
