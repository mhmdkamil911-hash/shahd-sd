import React, { useState } from 'react';
import { Trip } from '../types';
import Button from './ui/Button';
import ClockIcon from './icons/ClockIcon';
import UsersIcon from './icons/UsersIcon';
import MoneyIcon from './icons/MoneyIcon';
import CarIcon from './icons/CarIcon';
import BoxIcon from './icons/BoxIcon';
import ArrowLongLeftIcon from './icons/ArrowLongLeftIcon';
import UserIcon from './icons/UserIcon';
import CloudUploadIcon from './icons/CloudUploadIcon';

interface TripCardProps {
  trip: Trip;
  onBook: (trip: Trip) => void;
  onDeliverParcel: (trip: Trip) => void;
}

const InfoItem: React.FC<{ icon: React.ReactNode; text: React.ReactNode }> = ({ icon, text }) => (
    <div className="flex items-center gap-2 text-gray-600">
        {icon}
        <span className="text-sm font-medium">{text}</span>
    </div>
);

const getArabicDayOfWeek = (dateString: string): string => {
    const days = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
    try {
      const date = new Date(dateString);
      if (isNaN(date.getTime())) {
        return '';
      }
      return days[date.getDay()];
    } catch (e) {
      return '';
    }
};

const formatTimeAgo = (isoString?: string): string => {
    if (!isoString) return '';
    const date = new Date(isoString);
    const now = new Date();
    const seconds = Math.floor((now.getTime() - date.getTime()) / 1000);

    if (seconds < 60) return "قبل لحظات";

    let interval = seconds / 31536000;
    if (interval > 1) {
        const years = Math.floor(interval);
        return `قبل ${years} ${years > 1 ? 'سنوات' : 'سنة'}`;
    }
    interval = seconds / 2592000;
    if (interval > 1) {
        const months = Math.floor(interval);
        return `قبل ${months} ${months > 1 ? 'أشهر' : 'شهر'}`;
    }
    interval = seconds / 86400;
    if (interval > 1) {
        const days = Math.floor(interval);
        return `قبل ${days} ${days > 1 ? 'أيام' : 'يوم'}`;
    }
    interval = seconds / 3600;
    if (interval > 1) {
        const hours = Math.floor(interval);
        return `قبل ${hours} ${hours > 1 ? 'ساعات' : 'ساعة'}`;
    }
    interval = seconds / 60;
    if (interval > 1) {
        const minutes = Math.floor(interval);
        return `قبل ${minutes} ${minutes > 1 ? 'دقائق' : 'دقيقة'}`;
    }
    return "قبل لحظات";
};


const TripCard: React.FC<TripCardProps> = ({ trip, onBook, onDeliverParcel }) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const dayOfWeek = getArabicDayOfWeek(trip.date);
  const timeAgo = formatTimeAgo(trip.createdAt);

  const handleButtonClick = (e: React.MouseEvent, action: (trip: Trip) => void) => {
    e.stopPropagation(); // Prevent card from toggling when a button is clicked
    action(trip);
  };

  return (
    <div 
      className="bg-white/90 backdrop-blur-sm rounded-xl shadow-lg hover:shadow-xl transition-shadow duration-300 cursor-pointer relative"
      onClick={() => setIsExpanded(!isExpanded)}
    >
        {/* Driver profile picture - pops up. z-10 to be on top of the car image */}
        <div className={`absolute top-0 right-6 transform transition-all duration-500 ease-in-out z-10 ${isExpanded ? 'opacity-100 -translate-y-1/2' : 'opacity-0 translate-y-0 scale-50'}`}>
            <img 
                src={trip.driverProfilePictureUrl} 
                alt={trip.driverName}
                className="w-16 h-16 rounded-full object-cover border-4 border-white shadow-lg"
            />
        </div>

        {/* New inner wrapper to contain the content and maintain overflow-hidden for rounded corners */}
        <div className="flex flex-col rounded-xl overflow-hidden h-full">
            {/* Animated Car Picture Section */}
            <div className={`transition-all duration-500 ease-in-out overflow-hidden ${isExpanded ? 'max-h-40 opacity-100' : 'max-h-0 opacity-0'}`}>
                {trip.carPictureFrontUrl && (
                    <div className="h-40 bg-gray-200">
                        <img src={trip.carPictureFrontUrl} alt={trip.carInfo} className="w-full h-full object-cover" />
                    </div>
                )}
            </div>

            <div className="p-5 flex-grow">
                <div className="mb-4">
                    <div className="flex items-center justify-between">
                        <span className="font-bold text-sky-600 text-lg">{trip.from}</span>
                        <div className="flex-grow flex items-center justify-center px-4">
                            <ArrowLongLeftIcon className="w-10 h-10 text-gray-400" />
                        </div>
                        <span className="font-bold text-sky-600 text-lg">{trip.to}</span>
                    </div>
                </div>
                
                {/* Expandable Section */}
                <div className={`transition-all duration-500 ease-in-out overflow-hidden ${isExpanded ? 'max-h-40 opacity-100' : 'max-h-0 opacity-0'}`}>
                  <div className="space-y-3 text-right pt-4 border-t">
                      {timeAgo && <InfoItem icon={<CloudUploadIcon className="w-5 h-5 text-gray-400" />} text={<span className="text-gray-500">نُشرت {timeAgo}</span>} />}
                      <InfoItem icon={<UserIcon className="w-5 h-5 text-gray-400" />} text={trip.driverName} />
                      <InfoItem icon={<ClockIcon className="w-5 h-5 text-gray-400" />} text={`${trip.date} (${dayOfWeek}) - ${trip.time}`} />
                      <InfoItem icon={<CarIcon className="w-5 h-5 text-gray-400" />} text={trip.carInfo} />
                      <InfoItem icon={<UsersIcon className="w-5 h-5 text-gray-400" />} text={
                          trip.seats > 0 ? (
                              <>
                                  <span className="font-bold text-green-600">{trip.seats}</span> مقاعد متاحة
                              </>
                          ) : (
                              <span className="font-bold text-red-500">لا توجد مقاعد</span>
                          )
                      } />
                  </div>
                </div>
            </div>
            <div className="bg-gray-50/80 backdrop-blur-sm p-4 flex items-center justify-between border-t mt-auto">
                <div className="flex items-center gap-2 text-gray-600">
                    <MoneyIcon className="w-6 h-6 text-green-500" />
                    <span className="text-xl font-bold text-green-600">{trip.price} <span className="text-sm font-normal">ريال</span></span>
                </div>
                <div className="flex items-center gap-2">
                    <Button 
                        onClick={(e) => handleButtonClick(e, onDeliverParcel)}
                        className="!py-2 px-3 text-sm bg-teal-600 hover:bg-teal-700 flex items-center gap-1.5"
                    >
                        <BoxIcon className="w-4 h-4" />
                        <span>توصيل طرد</span>
                    </Button>
                    <Button 
                        onClick={(e) => handleButtonClick(e, onBook)} 
                        disabled={trip.seats === 0}
                        className="!py-2 px-5 text-base disabled:bg-gray-300 disabled:cursor-not-allowed"
                    >
                        {trip.seats > 0 ? 'احجز الآن' : 'مكتمل'}
                    </Button>
                </div>
            </div>
        </div>
    </div>
  );
};

export default TripCard;