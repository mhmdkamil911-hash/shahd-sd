
import React, { useState, useCallback, useEffect, useMemo } from 'react';
import { View, DriverData, Trip, Hotel, NewsItem, GalleryImage, User, UserRole, Booking, UserStatus, Parcel, SudaneseGathering } from './types';
import AdminDashboard from './components/AdminDashboard';
import TripListScreen from './components/TripListScreen';
import PostTripForm from './components/PostTripForm';
import HotelsScreen from './components/HotelsScreen';
import SudaneseGatheringsScreen from './components/SudaneseGatheringsScreen';
import DriverListScreen from './components/DriverListScreen';
import BookingModal from './components/BookingModal';
import ParcelModal from './components/ParcelModal';
import WelcomeSplashScreen from './components/WelcomeSplashScreen';
import AdminLoginScreen from './components/LoginScreen';
import LoginRegisterScreen from './components/LoginRegisterScreen';
import AccountScreen from './components/AccountScreen';
import ModeratorDashboard from './components/ModeratorDashboard';

const INITIAL_TRIPS: Omit<Trip, 'driverId' | 'carPictureFrontUrl' | 'driverProfilePictureUrl' | 'createdAt'>[] = [
    { id: 'trip_1', driverName: 'محمد الأحمد', driverMobile: '0512345678', from: 'الرياض', to: 'جدة', date: '2024-08-10', time: '09:00', seats: 3, price: 150, carInfo: 'تويوتا كامري 2023' },
    { id: 'trip_2', driverName: 'خالد عبدالله', driverMobile: '0587654321', from: 'الدمام', to: 'الرياض', date: '2024-08-11', time: '14:30', seats: 1, price: 120, carInfo: 'هيونداي اكسنت 2022' },
    { id: 'trip_3', driverName: 'سارة إبراهيم', driverMobile: '0555555555', from: 'جدة', to: 'المدينة المنورة', date: '2024-08-12', time: '18:00', seats: 4, price: 100, carInfo: 'فورد تورس 2024' },
    { id: 'trip_4', driverName: 'علي الغامدي', driverMobile: '0544444444', from: 'أبها', to: 'جدة', date: '2024-08-15', time: '08:00', seats: 2, price: 200, carInfo: 'شيفروليه تاهو 2023' },
];

// A transparent 1x1 pixel to use as a default background, preventing errors from corrupted base64 strings.
const DEFAULT_BACKGROUND_URL = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=';

const App: React.FC = () => {
    const [view, setView] = useState<View>(View.TRIP_LIST);
    const [showSplash, setShowSplash] = useState(() => !localStorage.getItem('kdad-splash-seen'));

    // State Management
    const [users, setUsers] = useState<User[]>(() => {
        const savedUsers = localStorage.getItem('kdad-users');
        return savedUsers ? JSON.parse(savedUsers) : [];
    });
    const [currentUser, setCurrentUser] = useState<User | null>(() => {
        const savedUser = sessionStorage.getItem('kdad-current-user');
        return savedUser ? JSON.parse(savedUser) : null;
    });
    const [drivers, setDrivers] = useState<DriverData[]>(() => {
        const savedDrivers = localStorage.getItem('kdad-drivers');
        return savedDrivers ? JSON.parse(savedDrivers) : [];
    });
    const [trips, setTrips] = useState<Trip[]>(() => {
        const savedTrips = localStorage.getItem('kdad-trips');
        return savedTrips ? JSON.parse(savedTrips) : [];
    });
    const [hotels, setHotels] = useState<Hotel[]>(() => {
        const savedHotels = localStorage.getItem('kdad-hotels');
        return savedHotels ? JSON.parse(savedHotels) : [];
    });
     const [gatherings, setGatherings] = useState<SudaneseGathering[]>(() => {
        const saved = localStorage.getItem('kdad-gatherings');
        return saved ? JSON.parse(saved) : [];
    });
    const [newsItems, setNewsItems] = useState<NewsItem[]>(() => {
        const savedNews = localStorage.getItem('kdad-news');
        return savedNews ? JSON.parse(savedNews) : [{id: 'news_1', text: 'مرحباً بكم في تطبيق كداد سوداني لخدمات التوصيل بين مدن المملكة.'}];
    });
    const [galleryImages, setGalleryImages] = useState<GalleryImage[]>(() => {
        const savedImages = localStorage.getItem('kdad-gallery');
        return savedImages ? JSON.parse(savedImages) : [];
    });
    const [bookings, setBookings] = useState<Booking[]>(() => {
        const saved = localStorage.getItem('kdad-bookings');
        return saved ? JSON.parse(saved) : [];
    });
    const [parcels, setParcels] = useState<Parcel[]>(() => {
        const saved = localStorage.getItem('kdad-parcels');
        return saved ? JSON.parse(saved) : [];
    });
    const [backgroundUrl, setBackgroundUrl] = useState(localStorage.getItem('kdad-background') || DEFAULT_BACKGROUND_URL);


    // Effects for persistence
    useEffect(() => { localStorage.setItem('kdad-users', JSON.stringify(users)); }, [users]);
    useEffect(() => { localStorage.setItem('kdad-drivers', JSON.stringify(drivers)); }, [drivers]);
    useEffect(() => { localStorage.setItem('kdad-trips', JSON.stringify(trips)); }, [trips]);
    useEffect(() => { localStorage.setItem('kdad-hotels', JSON.stringify(hotels)); }, [hotels]);
    useEffect(() => { localStorage.setItem('kdad-gatherings', JSON.stringify(gatherings)); }, [gatherings]);
    useEffect(() => { localStorage.setItem('kdad-news', JSON.stringify(newsItems)); }, [newsItems]);
    useEffect(() => { localStorage.setItem('kdad-gallery', JSON.stringify(galleryImages)); }, [galleryImages]);
    useEffect(() => { localStorage.setItem('kdad-bookings', JSON.stringify(bookings)); }, [bookings]);
    useEffect(() => { localStorage.setItem('kdad-parcels', JSON.stringify(parcels)); }, [parcels]);
    useEffect(() => {
        if (currentUser) {
            sessionStorage.setItem('kdad-current-user', JSON.stringify(currentUser));
        } else {
            sessionStorage.removeItem('kdad-current-user');
        }
    }, [currentUser]);
    useEffect(() => { localStorage.setItem('kdad-background', backgroundUrl); }, [backgroundUrl]);

    // Derived State
    const approvedDrivers = useMemo(() => {
        const activeDriverUserIds = users.filter(u => u.role === UserRole.DRIVER && u.status === 'active').map(u => u.id);
        return drivers.filter(d => activeDriverUserIds.includes(d.userId));
    }, [users, drivers]);

    const isCurrentUserDriverApproved = useMemo(() => {
        if (!currentUser || currentUser.role !== UserRole.DRIVER) return false;
        const driverProfile = drivers.find(d => d.userId === currentUser.id);
        return !!driverProfile && currentUser.status === 'active';
    }, [currentUser, drivers]);
    
    const augmentedTrips = useMemo(() => {
        return trips
            .map(trip => {
                const driverProfile = drivers.find(d => d.id === trip.driverId);
                const driverUser = users.find(u => u.id === driverProfile?.userId);
                if (!driverProfile || !driverUser) return null;
                return {
                    ...trip,
                    driverName: driverUser.fullName,
                    driverMobile: driverUser.mobile,
                    driverProfilePictureUrl: driverUser.profilePictureUrl,
                    // FIX: Replaced template literal with string concatenation for compatibility.
                    carInfo: driverProfile.carType + ' ' + driverProfile.carModel,
                    carPictureFrontUrl: driverProfile.carPictureFrontUrl,
                };
            })
            .filter((trip): trip is Trip => trip !== null)
            .sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime());
    }, [trips, drivers, users]);


    // Handlers
    const handleNavigate = useCallback((newView: View) => setView(newView), []);
    const handleBackToTripList = useCallback(() => setView(View.TRIP_LIST), []);

    const handlePostTrip = useCallback((data: Omit<Trip, 'id' | 'driverId' | 'driverName' | 'driverMobile' | 'carInfo' | 'carPictureFrontUrl' | 'driverProfilePictureUrl' | 'createdAt'>) => {
        if (!currentUser || currentUser.role !== UserRole.DRIVER) {
            alert("يجب أن تكون سائقاً لنشر رحلة.");
            return;
        }
        const driverProfile = drivers.find(d => d.userId === currentUser.id);
        if (!driverProfile) {
            alert("لم يتم العثور على بيانات السائق.");
            return;
        }
        const newTrip: Omit<Trip, 'driverName' | 'driverMobile' | 'carInfo' | 'carPictureFrontUrl' | 'driverProfilePictureUrl'> = {
            // FIX: Replaced template literal with string concatenation for compatibility.
            id: 'trip_' + Date.now(),
            driverId: driverProfile.id,
            createdAt: new Date().toISOString(),
            ...data,
        };
        setTrips(prev => [...prev, newTrip as Trip]);
        alert('تم نشر رحلتك بنجاح!');
        setView(View.TRIP_LIST);
    }, [currentUser, drivers]);
    
    const handleDeleteTrip = useCallback((tripId: string) => {
        if (window.confirm('هل أنت متأكد من حذف هذه الرحلة؟')) {
            setTrips(prev => prev.filter(t => t.id !== tripId));
        }
    }, []);

    const handleAddHotel = useCallback((hotelData: Omit<Hotel, 'id'>) => {
        // FIX: Replaced template literal with string concatenation for compatibility.
        const newHotel: Hotel = { id: 'hotel_' + Date.now(), ...hotelData };
        setHotels(prev => [...prev, newHotel]);
    }, []);
    
    const handleDeleteHotel = useCallback((hotelId: string) => {
         if (window.confirm('هل أنت متأكد من حذف هذا الفندق؟')) {
            setHotels(prev => prev.filter(h => h.id !== hotelId));
        }
    }, []);
    
    const handleAddGathering = useCallback((gatheringData: Omit<SudaneseGathering, 'id'>) => {
        // FIX: Replaced template literal with string concatenation for compatibility.
        const newGathering: SudaneseGathering = { id: 'gathering_' + Date.now(), ...gatheringData };
        setGatherings(prev => [...prev, newGathering]);
    }, []);

    const handleDeleteGathering = useCallback((gatheringId: string) => {
        if (window.confirm('هل أنت متأكد من حذف هذا المكان؟')) {
            setGatherings(prev => prev.filter(g => g.id !== gatheringId));
        }
    }, []);

    const handleAddNewsItem = useCallback((text: string) => {
        // FIX: Replaced template literal with string concatenation for compatibility.
        const newItem: NewsItem = { id: 'news_' + Date.now(), text };
        setNewsItems(prev => [newItem, ...prev]);
    }, []);

    const handleDeleteNewsItem = useCallback((newsId: string) => {
        setNewsItems(prev => prev.filter(item => item.id !== newsId));
    }, []);
    
    const handleAddGalleryImage = useCallback((imageUrl: string) => {
        // FIX: Replaced template literal with string concatenation for compatibility.
        const newImage: GalleryImage = { id: 'gallery_' + Date.now(), imageUrl };
        setGalleryImages(prev => [newImage, ...prev]);
    }, []);

    const handleDeleteGalleryImage = useCallback((imageId: string) => {
        setGalleryImages(prev => prev.filter(img => img.id !== imageId));
    }, []);

    const handleSetBackground = useCallback((imageUrl: string) => {
        setBackgroundUrl(imageUrl);
        alert('تم تحديث الخلفية بنجاح.');
    }, []);

    const handleRestoreDefaultBackground = useCallback(() => {
        setBackgroundUrl(DEFAULT_BACKGROUND_URL);
        alert('تم استعادة الخلفية الافتراضية.');
    }, []);

    const handleLogin = useCallback((mobile: string, password: string): boolean => {
        const user = users.find(u => u.mobile === mobile && u.password === password);
        if (user) {
            setCurrentUser(user);
            if (user.status === 'pending') {
                setView(View.ACCOUNT_PENDING_ACTIVATION);
            } else if (user.role === UserRole.MODERATOR) {
                setView(View.MODERATOR_DASHBOARD);
            }
             else {
                setView(View.TRIP_LIST);
            }
            return true;
        }
        return false;
    }, [users]);
    
    const handleAdminLogin = useCallback((user: string, pass: string): boolean => {
        // Simple admin credentials check
        if (user === 'kdad' && pass === 'm7mdbolaD') {
            const adminUser: User = {
                id: 'admin_user',
                fullName: 'Admin',
                mobile: '',
                email: '',
                password: '',
                profilePictureUrl: '',
                residencePermitUrl: '',
                role: UserRole.ADMIN,
                status: 'active',
            };
            setCurrentUser(adminUser);
            setView(View.ADMIN_DASHBOARD);
            return true;
        }
        return false;
    }, []);

    const handleRegister = useCallback((userData: Omit<User, 'id' | 'status'>, driverData?: Omit<DriverData, 'id' | 'userId'>): boolean => {
        if (users.some(u => u.mobile === userData.mobile)) {
            return false; // User already exists
        }
        const newUser: User = {
            // FIX: Replaced template literal with string concatenation for compatibility.
            id: 'user_' + Date.now(),
            ...userData,
            status: 'pending',
        };
        setUsers(prev => [...prev, newUser]);
        
        if (userData.role === UserRole.DRIVER && driverData) {
            const newDriver: DriverData = {
                // FIX: Replaced template literal with string concatenation for compatibility.
                id: 'driver_' + Date.now(),
                userId: newUser.id,
                ...driverData,
            };
            setDrivers(prev => [...prev, newDriver]);
        }

        setCurrentUser(newUser);
        setView(View.ACCOUNT_PENDING_ACTIVATION);
        return true;
    }, [users]);
    
    const handleLogout = useCallback(() => {
        setCurrentUser(null);
        setView(View.TRIP_LIST);
    }, []);
    
    const handleUserStatusUpdate = useCallback((userId: string, status: UserStatus) => {
        setUsers(prevUsers => prevUsers.map(u => u.id === userId ? { ...u, status } : u));
    }, []);

    const handleUserRoleUpdate = useCallback((userId: string, role: UserRole) => {
        setUsers(prevUsers => prevUsers.map(u => u.id === userId ? { ...u, role } : u));
        alert('تم تحديث دور المستخدم بنجاح.');
    }, []);
    
    const handleConfirmBooking = useCallback((tripId: string) => {
        if (!currentUser) {
            alert('الرجاء تسجيل الدخول أولاً لتأكيد الحجز.');
            setView(View.LOGIN_REGISTER);
            return;
        }
        const newBooking: Booking = {
            // FIX: Replaced template literal with string concatenation for compatibility.
            id: 'booking_' + Date.now(),
            tripId,
            passengerId: currentUser.id,
            bookingDate: new Date().toISOString(),
        };
        setBookings(prev => [...prev, newBooking]);
        setTrips(prev => prev.map(t => t.id === tripId ? {...t, seats: Math.max(0, t.seats - 1)} : t));
        alert('تم تأكيد حجزك بنجاح! يمكنك مراجعة حجوزاتك في صفحة حسابك.');
    }, [currentUser]);

    const handleConfirmParcel = useCallback((tripId: string) => {
        if (!currentUser) {
            alert('الرجاء تسجيل الدخول أولاً لتأكيد توصيل الطرد.');
            setView(View.LOGIN_REGISTER);
            return;
        }
        const newParcel: Parcel = {
            // FIX: Replaced template literal with string concatenation for compatibility.
            id: 'parcel_' + Date.now(),
            tripId,
            passengerId: currentUser.id,
            confirmationDate: new Date().toISOString(),
        };
        setParcels(prev => [...prev, newParcel]);
        alert('تم تأكيد طلب توصيل الطرد بنجاح! يمكنك مراجعة عمليتك في صفحة حسابك.');
    }, [currentUser]);

    // UI Rendering
    const [bookingTrip, setBookingTrip] = useState<Trip | null>(null);
    const [parcelTrip, setParcelTrip] = useState<Trip | null>(null);

    const renderContent = () => {
        switch (view) {
            case View.TRIP_LIST:
                return <TripListScreen 
                            trips={augmentedTrips} 
                            hotels={hotels}
                            gatherings={gatherings}
                            newsItems={newsItems}
                            galleryImages={galleryImages}
                            currentUser={currentUser}
                            isDriverApproved={isCurrentUserDriverApproved}
                            onStartBooking={(trip) => setBookingTrip(trip)} 
                            onStartParcelDelivery={(trip) => setParcelTrip(trip)}
                            onNavigate={handleNavigate} 
                        />;
            case View.POST_TRIP:
                return <PostTripForm onBack={handleBackToTripList} onSubmit={handlePostTrip} />;
            case View.ADMIN_DASHBOARD:
                 return currentUser?.role === UserRole.ADMIN ? (
                    <AdminDashboard 
                        users={users}
                        drivers={drivers}
                        trips={augmentedTrips}
                        hotels={hotels}
                        gatherings={gatherings}
                        newsItems={newsItems}
                        galleryImages={galleryImages}
                        onUserStatusUpdate={handleUserStatusUpdate}
                        onUserRoleUpdate={handleUserRoleUpdate}
                        onDeleteTrip={handleDeleteTrip}
                        onDeleteHotel={handleDeleteHotel}
                        onDeleteGathering={handleDeleteGathering}
                        onAddNewsItem={handleAddNewsItem}
                        onDeleteNewsItem={handleDeleteNewsItem}
                        onAddGalleryImage={handleAddGalleryImage}
                        onDeleteGalleryImage={handleDeleteGalleryImage}
                        onSetBackground={handleSetBackground}
                        onRestoreDefaultBackground={handleRestoreDefaultBackground}
                        onBack={handleBackToTripList}
                        onLogout={handleLogout}
                     />
                 ) : (
                    <AdminLoginScreen onLogin={handleAdminLogin} onBack={handleBackToTripList} />
                 );
             case View.MODERATOR_DASHBOARD:
                 const pendingDrivers = users.filter(u => u.role === UserRole.DRIVER && u.status === 'pending');
                 return currentUser?.role === UserRole.MODERATOR ? (
                     <ModeratorDashboard
                         pendingDrivers={pendingDrivers}
                         driversData={drivers}
                         onUserStatusUpdate={handleUserStatusUpdate}
                         onBack={handleBackToTripList}
                         onLogout={handleLogout}
                     />
                 ) : <TripListScreen 
                            trips={augmentedTrips} 
                            hotels={hotels}
                            gatherings={gatherings}
                            newsItems={newsItems}
                            galleryImages={galleryImages}
                            currentUser={currentUser}
                            isDriverApproved={isCurrentUserDriverApproved}
                            onStartBooking={(trip) => setBookingTrip(trip)} 
                            onStartParcelDelivery={(trip) => setParcelTrip(trip)}
                            onNavigate={handleNavigate} 
                        />;
            case View.HOTELS_LIST:
                return <HotelsScreen hotels={hotels} onAddHotel={handleAddHotel} onBack={handleBackToTripList} />;
            case View.GATHERINGS:
                return <SudaneseGatheringsScreen gatherings={gatherings} onAddGathering={handleAddGathering} onBack={handleBackToTripList} />;
            case View.DRIVERS_LIST:
                const activeDriversWithUsers = approvedDrivers.map(driver => {
                    const user = users.find(u => u.id === driver.userId);
                    return user ? { ...driver, fullName: user.fullName, mobile: user.mobile, profilePictureUrl: user.profilePictureUrl } : null;
                }).filter(Boolean);
                // FIX: Removed @ts-ignore by fixing props in DriverListScreen
                return <DriverListScreen drivers={activeDriversWithUsers as any} onBack={handleBackToTripList} />;
            case View.LOGIN_REGISTER:
                return <LoginRegisterScreen onLogin={handleLogin} onRegister={handleRegister} onBack={handleBackToTripList} />;
            case View.ACCOUNT_HISTORY:
                 if (!currentUser) { setView(View.LOGIN_REGISTER); return null; }
                 return <AccountScreen 
                            currentUser={currentUser} 
                            bookings={bookings}
                            parcels={parcels}
                            trips={trips}
                            drivers={drivers}
                            users={users}
                            onLogout={handleLogout}
                            onBack={handleBackToTripList} 
                        />;
             case View.ACCOUNT_PENDING_ACTIVATION:
                 if (!currentUser) { setView(View.LOGIN_REGISTER); return null; }
                 return (
                    <div className="bg-white/90 backdrop-blur-sm p-8 rounded-xl shadow-lg text-center max-w-lg mx-auto">
                        <h2 className="text-2xl font-bold text-sky-600 mb-4">شكراً لتسجيلك!</h2>
                        <p className="text-gray-700">مرحباً بك <span className="font-bold">{currentUser.fullName}</span>.</p>
                        <p className="text-gray-700 mt-2">حسابك قيد المراجعة حالياً من قبل الإدارة. سيتم تفعيله خلال 24 ساعة كحد أقصى.</p>
                        <p className="mt-4 bg-amber-100 text-amber-800 p-3 rounded-lg text-sm">ستتمكن من استخدام كافة ميزات التطبيق بعد تفعيل حسابك.</p>
                        <button onClick={handleLogout} className="mt-6 bg-sky-600 text-white font-bold py-2 px-6 rounded-lg hover:bg-sky-700">
                           تسجيل الخروج
                        </button>
                    </div>
                );

            default: return null;
        }
    };
    
    // Automatic trip population for demonstration if none exist
    useEffect(() => {
        const hasTrips = localStorage.getItem('kdad-trips');
        if (!hasTrips || JSON.parse(hasTrips).length === 0) {
            const demoUsers: User[] = [
                { id: 'user_driver_1', fullName: 'محمد الأحمد', mobile: '0512345678', email: 'mo@kdad.com', password: '123', profilePictureUrl: 'https://i.pravatar.cc/150?u=driver1', residencePermitUrl: 'https://via.placeholder.com/150', role: UserRole.DRIVER, status: 'active' },
                { id: 'user_driver_2', fullName: 'خالد عبدالله', mobile: '0587654321', email: 'kh@kdad.com', password: '123', profilePictureUrl: 'https://i.pravatar.cc/150?u=driver2', residencePermitUrl: 'https://via.placeholder.com/150', role: UserRole.DRIVER, status: 'active' },
                { id: 'user_driver_3', fullName: 'سارة إبراهيم', mobile: '0555555555', email: 'sa@kdad.com', password: '123', profilePictureUrl: 'https://i.pravatar.cc/150?u=driver3', residencePermitUrl: 'https://via.placeholder.com/150', role: UserRole.DRIVER, status: 'active' },
                { id: 'user_driver_4', fullName: 'علي الغامدي', mobile: '0544444444', email: 'ali@kdad.com', password: '123', profilePictureUrl: 'https://i.pravatar.cc/150?u=driver4', residencePermitUrl: 'https://via.placeholder.com/150', role: UserRole.DRIVER, status: 'active' },
            ];
            const demoDrivers: DriverData[] = [
                 { id: 'driver_1', userId: 'user_driver_1', city: 'الرياض', nationalId: '1...1', carType: 'تويوتا كامري', carModel: '2023', carColor: 'أبيض', plateNumber: 'أ ب ج 123', seats: '4', carPictureFrontUrl: 'https://via.placeholder.com/300x200/ffffff/000000?text=Camry+Front', carPictureRearUrl: 'https://via.placeholder.com/300x200/ffffff/000000?text=Camry+Rear' },
                 { id: 'driver_2', userId: 'user_driver_2', city: 'الدمام', nationalId: '1...2', carType: 'هيونداي اكسنت', carModel: '2022', carColor: 'فضي', plateNumber: 'د ه و 456', seats: '4', carPictureFrontUrl: 'https://via.placeholder.com/300x200/C0C0C0/000000?text=Accent+Front', carPictureRearUrl: 'https://via.placeholder.com/300x200/C0C0C0/000000?text=Accent+Rear' },
                 { id: 'driver_3', userId: 'user_driver_3', city: 'جدة', nationalId: '1...3', carType: 'فورد تورس', carModel: '2024', carColor: 'أسود', plateNumber: 'س ص ط 789', seats: '4', carPictureFrontUrl: 'https://via.placeholder.com/300x200/000000/FFFFFF?text=Taurus+Front', carPictureRearUrl: 'https://via.placeholder.com/300x200/000000/FFFFFF?text=Taurus+Rear' },
                 { id: 'driver_4', userId: 'user_driver_4', city: 'أبها', nationalId: '1...4', carType: 'شيفروليه تاهو', carModel: '2023', carColor: 'أزرق', plateNumber: 'ع غ ف 987', seats: '7', carPictureFrontUrl: 'https://via.placeholder.com/300x200/0000FF/FFFFFF?text=Tahoe+Front', carPictureRearUrl: 'https://via.placeholder.com/300x200/0000FF/FFFFFF?text=Tahoe+Rear' },
            ];
             const demoTrips: Omit<Trip, 'driverName' | 'driverMobile' | 'carInfo' | 'carPictureFrontUrl' | 'driverProfilePictureUrl'>[] = INITIAL_TRIPS.map((trip, index) => ({
                ...trip,
                driverId: demoDrivers[index].id,
                createdAt: new Date(Date.now() - index * 3600000).toISOString(), // Stagger creation times
            }));
            
            setUsers(prev => [...prev, ...demoUsers]);
            setDrivers(prev => [...prev, ...demoDrivers]);
            setTrips(demoTrips as Trip[]); // Cast because the augmented properties will be added later
        }
    }, []);

    const handleDismissSplash = () => {
        localStorage.setItem('kdad-splash-seen', 'true');
        setShowSplash(false);
    };

    return (
      // FIX: Replaced template literal with string concatenation for compatibility.
      <div id="app-background" className="bg-gray-200" style={{ backgroundImage: 'url(' + backgroundUrl + '), linear-gradient(rgba(0,0,0,0.2), rgba(0,0,0,0.2))' }}>
        <div className="container mx-auto px-4 py-8">
            {showSplash && <WelcomeSplashScreen onDismiss={handleDismissSplash} />}
            {bookingTrip && <BookingModal trip={bookingTrip} onClose={() => setBookingTrip(null)} onConfirmBooking={(tripId) => { handleConfirmBooking(tripId); setBookingTrip(null); }} />}
            {parcelTrip && <ParcelModal trip={parcelTrip} onClose={() => setParcelTrip(null)} onConfirmParcelDelivery={(tripId) => { handleConfirmParcel(tripId); setParcelTrip(null); }} />}
            {renderContent()}
        </div>
      </div>
    );
};

export default App;
