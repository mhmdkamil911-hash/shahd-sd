
export enum UserRole {
  DRIVER = 'driver',
  PASSENGER = 'passenger',
  ADMIN = 'admin',
  MODERATOR = 'moderator',
}

export type UserStatus = 'pending' | 'active' | 'rejected';

export enum View {
  TRIP_LIST,
  POST_TRIP,
  ADMIN_DASHBOARD,
  HOTELS_LIST,
  DRIVERS_LIST,
  ADMIN_LOGIN,
  LOGIN_REGISTER,
  ACCOUNT_HISTORY,
  ACCOUNT_PENDING_ACTIVATION,
  GATHERINGS,
  MODERATOR_DASHBOARD,
}

export interface User {
  id: string;
  fullName: string;
  mobile: string;
  email: string;
  profilePictureUrl: string;
  residencePermitUrl: string;
  password: string;
  role: UserRole;
  status: UserStatus;
}

export interface DriverData {
  id: string;
  userId: string;
  city: string;
  nationalId: string;
  carType: string;
  carModel: string;
  carColor: string;
  plateNumber: string;
  seats: string;
  carPictureFrontUrl: string;
  carPictureRearUrl: string;
}

export interface Trip {
  id:string;
  driverId: string;
  driverName: string;
  driverMobile: string;
  from: string;
  to: string;
  date: string;
  time: string;
  seats: number;
  price: number;
  carInfo: string;
  carPictureFrontUrl: string;
  driverProfilePictureUrl: string;
  createdAt?: string;
}

export interface Booking {
  id: string;
  tripId: string;
  passengerId: string;
  bookingDate: string;
}

export interface Parcel {
  id: string;
  tripId: string;
  passengerId: string; // The user who sent the parcel
  confirmationDate: string;
}

export interface Hotel {
    id: string;
    name: string;
    contact: string;
    images: string[];
    locationUrl: string;
}

export enum GatheringType {
  RESTAURANT = 'restaurant',
  SHOP = 'shop',
  OTHER = 'other',
}

export interface SudaneseGathering {
    id: string;
    name: string;
    contact: string;
    type: GatheringType;
    images: string[];
    locationUrl: string;
}

export interface NewsItem {
  id: string;
  text: string;
}

export interface GalleryImage {
  id: string;
  imageUrl: string;
}
